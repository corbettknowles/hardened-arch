#!/usr/bin/env python3
"""Patch the current Hardened Arch ISO builder to use source-built X.Org and
source-built Limine while preserving unrelated physical-boot repairs.

The patcher creates a timestamped backup and syntax-checks the modified builder
before writing it.
"""

from __future__ import annotations

import argparse
import datetime as dt
import re
import shutil
import sys
from pathlib import Path


class PatchError(RuntimeError):
    pass


LIMINE_FUNCTIONS = '\ndef limine_config(kver: str, label: str) -> str:\n    return textwrap.dedent(\n        f"""\\\n        # Hardened Arch live/install/update Limine configuration\n        timeout: 8\n        default_entry: 1\n        graphics: yes\n        interface_resolution: 1920x1080\n        interface_branding: HARDENED ARCH LINUX\n        interface_branding_colour: ff3038\n        interface_help_hidden: no\n        interface_help_colour: d8dde8\n        interface_help_colour_bright: ff3a40\n        wallpaper: boot():/EFI/BOOT/limine-bg.png\n        wallpaper_style: stretched\n        term_font_scale: 2x2\n        term_font_spacing: 1\n        term_margin: 250\n        term_margin_gradient: 28\n        term_background: 980b1321\n        term_foreground: f4f6fb\n        term_background_bright: 301018\n        term_foreground_bright: ffffff\n        term_palette: 10131a;d92b38;3da85b;d6a83d;4d78d8;a858c7;45a8b8;d8dde8\n        term_palette_bright: 4b5262;ff3646;56d878;ffd35a;6e9cff;dc79f2;67d7e8;ffffff\n        editor_enabled: no\n\n        /Hardened Arch Linux (default)\n            comment: Start the graphical live system\n            protocol: linux\n            path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n            module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n            cmdline: iso_label={label} hardened.mode=live rw quiet splash systemd.unit=graphical.target\n\n        /+Advanced options for Hardened Arch Linux\n            comment: Installation, recovery, and diagnostic boot modes\n\n            //Install Hardened Arch Linux to Disk\n                protocol: linux\n                path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n                module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n                cmdline: iso_label={label} hardened.mode=install rw systemd.unit=hardened-installer.target\n\n            //Check for Software Updates / Recovery\n                protocol: linux\n                path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n                module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n                cmdline: iso_label={label} hardened.mode=update rw systemd.unit=hardened-update.target\n\n            //Verbose hardware diagnostic boot\n                protocol: linux\n                path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n                module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n                cmdline: iso_label={label} hardened.mode=live rw loglevel=7 systemd.log_level=debug systemd.show_status=yes\n        """\n    )\n\n\ndef find_limine_efi(limine_dir: Path) -> Path:\n    candidates = (\n        limine_dir / "BOOTX64.EFI",\n        limine_dir / "bootx64.efi",\n        limine_dir / "limine_x64.efi",\n    )\n    for candidate in candidates:\n        if candidate.is_file():\n            return candidate\n    raise BuildError(\n        "Source-built Limine UEFI binary was not found. Expected one of:\\n  "\n        + "\\n  ".join(str(path) for path in candidates)\n    )\n\n\ndef find_limine_background(theme_dir: Path) -> Path:\n    candidates = (\n        theme_dir / "limine-bg.png",\n        theme_dir / "refind_bg.png",\n        theme_dir / "background.png",\n        theme_dir / "refind_bg_png",\n    )\n    for candidate in candidates:\n        if candidate.is_file():\n            return candidate\n    raise BuildError(\n        "No Hardened Arch boot background was found. Expected limine-bg.png "\n        "or refind_bg.png in " + str(theme_dir)\n    )\n\n\ndef prepare_esp(paths: BuildPaths, cfg: BuildConfig, kver: str, kernel: Path, installed_initrd: Path) -> None:\n    print("\\n== Preparing source-built Limine ESP ==")\n    efi_boot = paths.esp_root / "EFI/BOOT"\n    efi_linux = paths.esp_root / "EFI/Linux"\n    for directory in (efi_boot, efi_linux):\n        directory.mkdir(parents=True, exist_ok=True)\n\n    limine_efi = find_limine_efi(paths.limine_dir)\n    background = find_limine_background(paths.theme_dir)\n\n    copy_file(limine_efi, efi_boot / "BOOTX64.EFI")\n    copy_file(background, efi_boot / "limine-bg.png")\n    write_text(efi_boot / "limine.conf", limine_config(kver, cfg.volume_label))\n\n    source_record = paths.limine_dir / "source-build.txt"\n    if source_record.is_file():\n        copy_file(source_record, efi_boot / "limine-source-build.txt")\n\n    copy_file(kernel, efi_linux / f"vmlinuz-{kver}.efi")\n    copy_file(paths.live_initrd, efi_linux / f"initramfs-live-{kver}.img.zst")\n    copy_file(installed_initrd, efi_linux / f"initramfs-{kver}.img.zst")\n\n    # Put the exact installable ESP tree in the live root.\n    live_efi = paths.live_root / "boot/EFI"\n    if live_efi.exists():\n        shutil.rmtree(live_efi)\n    shutil.copytree(paths.esp_root / "EFI", live_efi, symlinks=True)\n\n\n'
INSTALLER_LIMINE_BLOCK = 'cat > "$TARGET_MNT/boot/EFI/BOOT/limine.conf" <<EOF\n# Hardened Arch installed-system Limine configuration\ntimeout: 8\ndefault_entry: 1\ngraphics: yes\ninterface_resolution: 1920x1080\ninterface_branding: HARDENED ARCH LINUX\ninterface_branding_colour: ff3038\ninterface_help_hidden: no\ninterface_help_colour: d8dde8\ninterface_help_colour_bright: ff3a40\nwallpaper: boot():/EFI/BOOT/limine-bg.png\nwallpaper_style: stretched\nterm_font_scale: 2x2\nterm_font_spacing: 1\nterm_margin: 250\nterm_margin_gradient: 28\nterm_background: 980b1321\nterm_foreground: f4f6fb\nterm_background_bright: 301018\nterm_foreground_bright: ffffff\nterm_palette: 10131a;d92b38;3da85b;d6a83d;4d78d8;a858c7;45a8b8;d8dde8\nterm_palette_bright: 4b5262;ff3646;56d878;ffd35a;6e9cff;dc79f2;67d7e8;ffffff\neditor_enabled: no\n\n/Hardened Arch Linux (default)\n    comment: Start the installed graphical system\n    protocol: linux\n    path: boot():/EFI/Linux/vmlinuz-$KVER.efi\n    module_path: boot():/EFI/Linux/initramfs-$KVER.img.zst\n    cmdline: root=UUID=$ROOT_UUID rootfstype=btrfs rootflags=subvol=@ rw quiet splash\n\n/+Advanced options for Hardened Arch Linux\n    comment: Recovery and diagnostic modes\n\n    //Check for Software Updates / Recovery\n        protocol: linux\n        path: boot():/EFI/Linux/vmlinuz-$KVER.efi\n        module_path: boot():/EFI/Linux/initramfs-$KVER.img.zst\n        cmdline: root=UUID=$ROOT_UUID rootfstype=btrfs rootflags=subvol=@ rw systemd.unit=hardened-update.target\n\n    //Verbose diagnostic boot\n        protocol: linux\n        path: boot():/EFI/Linux/vmlinuz-$KVER.efi\n        module_path: boot():/EFI/Linux/initramfs-$KVER.img.zst\n        cmdline: root=UUID=$ROOT_UUID rootfstype=btrfs rootflags=subvol=@ rw loglevel=7 systemd.log_level=debug systemd.show_status=yes\nEOF\n'


def parse_args() -> argparse.Namespace:
    home = Path.home()
    parser = argparse.ArgumentParser(
        description="Patch Hardened Arch ISO builder for source X.Org and Limine."
    )
    parser.add_argument(
        "--builder",
        type=Path,
        default=home / "build_hardened_arch_iso.py",
        help="Existing ISO builder to patch",
    )
    parser.add_argument(
        "--theme-dir",
        type=Path,
        default=home / "boot-theme-build/refind/hardened-arch",
        help="Existing Hardened Arch boot-theme assets",
    )
    parser.add_argument(
        "--runtime-root",
        type=Path,
        default=home / "xorg-source-stage/rootfs",
        help="Default source-built runtime stage to inject into the builder",
    )
    parser.add_argument(
        "--limine-dir",
        type=Path,
        default=home / "bootloader-build/limine",
        help="Directory containing source-built BOOTX64.EFI",
    )
    parser.add_argument(
        "--no-compose-background",
        action="store_true",
        help="Do not generate limine-bg.png from existing theme assets",
    )
    return parser.parse_args()


def replace_once(
    source: str,
    pattern: str,
    replacement: str,
    label: str,
    *,
    flags: int = 0,
) -> str:
    updated, count = re.subn(
        pattern, replacement, source, count=1, flags=flags
    )
    if count != 1:
        raise PatchError(
            f"Could not uniquely patch {label}; matches={count}"
        )
    return updated


def replace_literal_once(
    source: str,
    pattern: str,
    replacement: str,
    label: str,
    *,
    flags: int = 0,
) -> str:
    regex = re.compile(pattern, flags)
    matches = list(regex.finditer(source))
    if len(matches) != 1:
        raise PatchError(
            f"Could not uniquely patch {label}; matches={len(matches)}"
        )
    return regex.sub(lambda _match: replacement, source, count=1)


def compose_background(theme_dir: Path) -> Path:
    output = theme_dir / "limine-bg.png"
    backgrounds = (
        theme_dir / "refind_bg.png",
        theme_dir / "background.png",
        theme_dir / "refind_bg_png",
    )
    background = next((p for p in backgrounds if p.is_file()), None)
    if background is None:
        raise PatchError(f"No background source found in {theme_dir}")

    try:
        from PIL import Image
    except ImportError:
        shutil.copy2(background, output)
        print(
            "Pillow is unavailable; copied the existing background without "
            "compositing the panel/logo."
        )
        return output

    resampling = getattr(Image, "Resampling", Image)
    canvas = Image.open(background).convert("RGBA").resize(
        (1920, 1080), resampling.LANCZOS
    )

    panel_candidates = (
        theme_dir / "refind_panel.png",
        theme_dir / "panel.png",
    )
    panel = next((p for p in panel_candidates if p.is_file()), None)
    if panel is not None:
        panel_img = Image.open(panel).convert("RGBA").resize(
            (1120, 500), resampling.LANCZOS
        )
        canvas.alpha_composite(
            panel_img, ((1920 - 1120) // 2, 455)
        )

    logo_candidates = (
        theme_dir / "refind_icon.png",
        theme_dir / "icons/os_hardened_arch.png",
        theme_dir / "logo.png",
    )
    logo = next((p for p in logo_candidates if p.is_file()), None)
    if logo is not None:
        logo_img = Image.open(logo).convert("RGBA")
        logo_img.thumbnail((280, 280), resampling.LANCZOS)
        canvas.alpha_composite(
            logo_img, ((1920 - logo_img.width) // 2, 62)
        )

    canvas.convert("RGB").save(output, optimize=True)
    return output


def patch_builder(
    source: str,
    *,
    runtime_root: Path,
    limine_dir: Path,
) -> str:
    if "def limine_config(" in source and "limine_dir: Path" in source:
        raise PatchError(
            "Builder already appears to be patched for Limine."
        )

    # Never ask the ISO builder to install a binary rEFInd package.
    source = re.sub(
        r'(?m)^\s*"refind",\s*\n', "", source, count=1
    )

    source = replace_once(
        source,
        r"(?m)^(\s+theme_dir: Path\s*)$",
        r"\1\n    limine_dir: Path",
        "BuildPaths.limine_dir",
    )

    source = replace_once(
        source,
        r'(?m)^(\s+parser\.add_argument\("--theme-dir", type=Path\)\s*)$',
        r'\1\n    parser.add_argument("--limine-dir", type=Path)',
        "--limine-dir argument",
    )

    source = replace_once(
        source,
        r'(?m)^(\s+theme_dir = \(args\.theme_dir or home / "boot-theme-build/refind/hardened-arch"\)\.resolve\(\)\s*)$',
        (
            r'\1\n'
            + "    limine_dir = "
            + f"(args.limine_dir or Path({str(limine_dir)!r})).resolve()"
        ),
        "limine_dir path",
    )

    source = replace_once(
        source,
        r'(?m)^\s*runtime_root = \(args\.runtime_root or home / "runtime-package-root"\)\.resolve\(\)\s*$',
        (
            "    runtime_root = "
            f"(args.runtime_root or Path({str(runtime_root)!r})).resolve()"
        ),
        "source runtime default",
    )

    source = replace_once(
        source,
        r"(?m)^(\s+theme_dir=theme_dir,\s*)$",
        r"\1\n        limine_dir=limine_dir,",
        "BuildPaths constructor",
    )

    source = replace_once(
        source,
        r"(?m)^(\s+paths\.theme_dir,\s*)$",
        r"\1\n        paths.limine_dir,",
        "Limine validation directory",
    )

    # Replace only the rEFInd config/ESP functions. Physical-media initramfs
    # repairs elsewhere in the builder remain untouched.
    source = replace_literal_once(
        source,
        r"(?ms)^def refind_config\(.*?(?=^def build_squashfs\()",
        LIMINE_FUNCTIONS,
        "rEFInd ESP functions",
    )

    # The disk installer previously generated a second rEFInd configuration.
    source = replace_literal_once(
        source,
        r'(?ms)^cat > "\$TARGET_MNT/boot/EFI/BOOT/refind\.conf" <<EOF\n.*?^cp -f "\$TARGET_MNT/boot/EFI/BOOT/refind\.conf".*?\n',
        INSTALLER_LIMINE_BLOCK,
        "installed-system boot configuration",
    )

    source = source.replace(
        "This installs a UEFI rEFInd system with a Btrfs root and @ subvolume.",
        "This installs a UEFI Limine system with a Btrfs root and @ subvolume.",
    )
    source = source.replace(
        "unless the rEFInd binary and kernel are signed",
        "unless the Limine binary and kernel are signed",
    )

    return source


def main() -> int:
    args = parse_args()
    builder = args.builder.expanduser().resolve()
    theme_dir = args.theme_dir.expanduser().resolve()
    runtime_root = args.runtime_root.expanduser().resolve()
    limine_dir = args.limine_dir.expanduser().resolve()

    if not builder.is_file():
        raise PatchError(f"Builder not found: {builder}")
    if not theme_dir.is_dir():
        raise PatchError(f"Theme directory not found: {theme_dir}")
    if not runtime_root.is_dir():
        raise PatchError(
            f"Source-built runtime stage is missing: {runtime_root}\n"
            "Run rebuild_xorg_source_stack.sh first."
        )
    if not (limine_dir / "BOOTX64.EFI").is_file():
        raise PatchError(
            "Source-built Limine binary is missing: "
            f"{limine_dir / 'BOOTX64.EFI'}\n"
            "Run build_limine_from_source.sh first."
        )

    if not args.no_compose_background:
        background = compose_background(theme_dir)
        print(f"Prepared Limine background: {background}")

    original = builder.read_text(encoding="utf-8")
    patched = patch_builder(
        original,
        runtime_root=runtime_root,
        limine_dir=limine_dir,
    )

    # Parse before touching the current builder.
    compile(patched, str(builder), "exec")

    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = builder.with_name(
        f"{builder.name}.before-limine-{stamp}.bak"
    )
    shutil.copy2(builder, backup)
    builder.write_text(patched, encoding="utf-8")
    builder.chmod(0o755)

    print("\nISO BUILDER PATCHED")
    print(f"Builder:        {builder}")
    print(f"Backup:         {backup}")
    print(f"Runtime root:   {runtime_root}")
    print(f"Limine binary:  {limine_dir / 'BOOTX64.EFI'}")
    print(f"Theme:          {theme_dir / 'limine-bg.png'}")
    print(
        "\nThe builder now defaults to the source-built X.Org stage "
        "and no longer copies or installs rEFInd into the ESP."
    )
    print(
        "Do not rerun the old rEFInd-specific physical-boot repair "
        "script after this patch; its live-init changes are already preserved."
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (PatchError, OSError, SyntaxError) as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
