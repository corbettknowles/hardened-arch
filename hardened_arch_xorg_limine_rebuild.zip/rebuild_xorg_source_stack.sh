#!/usr/bin/env bash
# Build the complete buildable X.Org modular stack from official upstream
# source, overlay it onto the existing Hardened Arch runtime, and export a clean
# staging root for the ISO builder.
#
# pacman is used only inside a disposable dependency chroot. The exported
# staging root contains the source-built files and has stale package ownership
# records removed for packages whose files were replaced.
#
# Usage:
#   sudo ./rebuild_xorg_source_stack.sh
#
# Overrides:
#   BASE_ROOT=~/runtime-package-root
#   STAGE_ROOT=~/xorg-source-stage/rootfs
#   WORK_ROOT=~/xorg-source-build
#   XSERVER_TAG=xorg-server-21.1.24
#   JOBS=4
#   STRICT_ALL=1
#   EXPECTED_MODULES=230
#   RESUME=1          # continue an interrupted build using the existing overlay

set -Eeuo pipefail
shopt -s nullglob

die() {
    printf '\nERROR: %s\n' "$*" >&2
    exit 1
}

log() {
    printf '\n==> %s\n' "$*"
}

[[ $EUID -eq 0 ]] || die "Run this script with sudo."

OWNER="${SUDO_USER:-root}"
OWNER_HOME="$(getent passwd "$OWNER" | cut -d: -f6)"
[[ -n "$OWNER_HOME" && -d "$OWNER_HOME" ]] ||
    die "Could not determine the invoking user's home."

BASE_ROOT="${BASE_ROOT:-$OWNER_HOME/runtime-package-root}"
STAGE_ROOT="${STAGE_ROOT:-$OWNER_HOME/xorg-source-stage/rootfs}"
WORK_ROOT="${WORK_ROOT:-$OWNER_HOME/xorg-source-build}"
XSERVER_TAG="${XSERVER_TAG:-xorg-server-21.1.24}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"
EXPECTED_MODULES="${EXPECTED_MODULES:-230}"
STRICT_ALL="${STRICT_ALL:-0}"
RESUME="${RESUME:-0}"

DEPS_ROOT="$WORK_ROOT/deps-root"
UPPER_ROOT="$WORK_ROOT/source-upper"
OVERLAY_WORK="$WORK_ROOT/overlay-work"
MERGED_ROOT="$WORK_ROOT/build-root"
SOURCE_TREE="$WORK_ROOT/source-tree"
LOG_DIR="$WORK_ROOT/logs"
REPORT_DIR="$WORK_ROOT/reports"
BUILT_MODULES="$WORK_ROOT/built.modules"
BUILD_LOG="$LOG_DIR/xorg-modular-build.log"
MANIFEST="$REPORT_DIR/source-manifest.tsv"
FAILURES="$REPORT_DIR/module-failures.txt"
OWNERS_FILE="$REPORT_DIR/replaced-package-owners.txt"
VERIFY_LOG="$REPORT_DIR/stage-verification.txt"

MOUNTS=()

cleanup() {
    set +e
    for ((i=${#MOUNTS[@]}-1; i>=0; i--)); do
        mountpoint -q "${MOUNTS[$i]}" && umount -l "${MOUNTS[$i]}"
    done
}
trap cleanup EXIT INT TERM

mount_bind() {
    local src=$1 dst=$2
    mkdir -p "$dst"
    mount --rbind "$src" "$dst"
    mount --make-rslave "$dst"
    MOUNTS+=("$dst")
}

mount_file_bind() {
    local src=$1 dst=$2
    mkdir -p "$(dirname "$dst")"
    touch "$dst"
    mount --bind "$src" "$dst"
    MOUNTS+=("$dst")
}

safe_rm_tree() {
    local path
    path="$(readlink -m "$1")"
    case "$path" in
        /|/home|/root|/mnt|"$OWNER_HOME"|"$BASE_ROOT")
            die "Refusing to remove unsafe path: $path"
            ;;
    esac
    [[ ${#path} -ge 12 ]] ||
        die "Refusing suspiciously short removal path: $path"
    rm -rf --one-file-system "$path"
}

root_exec() {
    local root=$1
    shift
    chroot "$root" /usr/bin/env -i \
        HOME=/root \
        USER=root \
        LOGNAME=root \
        SHELL=/bin/bash \
        PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
        LANG=C.UTF-8 \
        LC_ALL=C.UTF-8 \
        MAKEFLAGS="-j$JOBS" \
        NINJAFLAGS="-j$JOBS" \
        "$@"
}

[[ -d "$BASE_ROOT/usr" ]] ||
    die "Runtime root is missing or invalid: $BASE_ROOT"
[[ -x "$BASE_ROOT/usr/bin/bash" ]] ||
    die "Runtime root has no /usr/bin/bash."
[[ -x "$BASE_ROOT/usr/bin/pacman" ]] ||
    die "Runtime root has no pacman. It is needed only in the disposable dependency root."
[[ -e "$BASE_ROOT/usr/lib/libc.so.6" ]] ||
    die "Runtime root has no glibc."

for cmd in rsync mount umount mountpoint chroot git find awk sed grep sort readelf ldd timeout; do
    command -v "$cmd" >/dev/null 2>&1 || die "Host command missing: $cmd"
done

log "Configuration"
printf '  Base runtime:      %s\n' "$BASE_ROOT"
printf '  Source stage:      %s\n' "$STAGE_ROOT"
printf '  Work directory:    %s\n' "$WORK_ROOT"
printf '  X server tag:      %s\n' "$XSERVER_TAG"
printf '  Jobs:              %s\n' "$JOBS"
printf '  Strict all:        %s\n' "$STRICT_ALL"
printf '  Resume:            %s\n' "$RESUME"

mkdir -p "$WORK_ROOT" "$SOURCE_TREE" "$LOG_DIR" "$REPORT_DIR"
rm -f "$BUILD_LOG" "$FAILURES" "$OWNERS_FILE" "$VERIFY_LOG"

if [[ "$RESUME" == 1 ]]; then
    [[ -d "$DEPS_ROOT/usr" ]] ||
        die "RESUME=1 requested, but dependency root is missing: $DEPS_ROOT"
    [[ -d "$UPPER_ROOT" && -d "$OVERLAY_WORK" ]] ||
        die "RESUME=1 requested, but the source overlay is missing."
    log "Reusing disposable dependency root and source overlay"
else
    log "Creating disposable build-dependency root"
    safe_rm_tree "$DEPS_ROOT"
    mkdir -p "$DEPS_ROOT"
    rsync -aHAX --numeric-ids --delete "$BASE_ROOT/" "$DEPS_ROOT/"

    mount_bind /dev "$DEPS_ROOT/dev"
    mount_bind /proc "$DEPS_ROOT/proc"
    mount_bind /sys "$DEPS_ROOT/sys"
    mount_bind /run "$DEPS_ROOT/run"
    if [[ -f /etc/resolv.conf ]]; then
        mount_file_bind /etc/resolv.conf "$DEPS_ROOT/etc/resolv.conf"
    fi
fi

REQUIRED_BUILD_PACKAGES=(
    base-devel git autoconf automake libtool pkgconf
    meson ninja cmake python python-mako python-yaml python-packaging
    bison flex gperf gettext nasm yasm
)

OPTIONAL_BUILD_PACKAGES=(
    python-setuptools python-docutils
    xmlto docbook-xsl libxslt asciidoc doxygen graphviz
    wayland-protocols
    freetype2 fontconfig libpng zlib bzip2 brotli expat
    libffi libunwind libpciaccess systemd-libs dbus openssl libgcrypt libmd
    cairo pango libepoxy libevdev libinput mtdev
    llvm clang glslang spirv-tools libclc rust bindgen
    xorg-util-macros
)

if [[ "$RESUME" != 1 ]]; then
    log "Installing build dependencies inside disposable root only"
    root_exec "$DEPS_ROOT" pacman -Sy --needed --noconfirm archlinux-keyring
    root_exec "$DEPS_ROOT" pacman -S --needed --noconfirm \
        "${REQUIRED_BUILD_PACKAGES[@]}"

    # Optional packages vary between Arch snapshots. Install every available
    # one, but do not abort because one was renamed or removed.
    for pkg in "${OPTIONAL_BUILD_PACKAGES[@]}"; do
        if root_exec "$DEPS_ROOT" pacman -Si "$pkg" >/dev/null 2>&1; then
            root_exec "$DEPS_ROOT" pacman -S --needed --noconfirm "$pkg"
        else
            printf 'Optional build package unavailable: %s\n' "$pkg" |
                tee -a "$BUILD_LOG"
        fi
    done

    # Freeze the dependency root before using it as overlay lowerdir.
    cleanup
    MOUNTS=()
fi

log "Creating isolated source-install overlay"
if [[ "$RESUME" != 1 ]]; then
    safe_rm_tree "$UPPER_ROOT"
    safe_rm_tree "$OVERLAY_WORK"
fi
safe_rm_tree "$MERGED_ROOT"
mkdir -p "$UPPER_ROOT" "$OVERLAY_WORK" "$MERGED_ROOT"

mount -t overlay overlay \
    -o "lowerdir=$DEPS_ROOT,upperdir=$UPPER_ROOT,workdir=$OVERLAY_WORK" \
    "$MERGED_ROOT"
MOUNTS+=("$MERGED_ROOT")

mount_bind /dev "$MERGED_ROOT/dev"
mount_bind /proc "$MERGED_ROOT/proc"
mount_bind /sys "$MERGED_ROOT/sys"
mount_bind /run "$MERGED_ROOT/run"
mkdir -p "$MERGED_ROOT/build"
mount --bind "$WORK_ROOT" "$MERGED_ROOT/build"
MOUNTS+=("$MERGED_ROOT/build")
if [[ -f /etc/resolv.conf ]]; then
    mount_file_bind /etc/resolv.conf "$MERGED_ROOT/etc/resolv.conf"
fi

log "Fetching official X.Org modular build script"
if [[ ! -d "$SOURCE_TREE/util/modular/.git" ]]; then
    git clone https://gitlab.freedesktop.org/xorg/util/modular.git \
        "$SOURCE_TREE/util/modular"
elif [[ "$RESUME" != 1 ]]; then
    git -C "$SOURCE_TREE/util/modular" fetch --all --tags --prune
    git -C "$SOURCE_TREE/util/modular" reset --hard origin/master
fi

log "Pinning xserver to $XSERVER_TAG"
if [[ ! -d "$SOURCE_TREE/xserver/.git" ]]; then
    git clone https://gitlab.freedesktop.org/xorg/xserver.git \
        "$SOURCE_TREE/xserver"
fi
if [[ "$RESUME" != 1 ]]; then
    git -C "$SOURCE_TREE/xserver" fetch --all --tags --prune
    git -C "$SOURCE_TREE/xserver" checkout --detach --force "$XSERVER_TAG"
    git -C "$SOURCE_TREE/xserver" clean -ffdqx
else
    current_xserver="$(
        git -C "$SOURCE_TREE/xserver" describe --exact-match --tags HEAD \
            2>/dev/null || true
    )"
    [[ "$current_xserver" == "$XSERVER_TAG" ]] ||
        die "RESUME=1 xserver checkout is $current_xserver, expected $XSERVER_TAG."
fi

if [[ "$RESUME" != 1 ]]; then
    rm -f "$BUILT_MODULES"
    find "$SOURCE_TREE" -mindepth 1 -maxdepth 3 -type d \
        \( -name build -o -name _build -o -name autom4te.cache \) \
        -prune -exec rm -rf {} + 2>/dev/null || true
else
    [[ -f "$BUILT_MODULES" ]] ||
        die "RESUME=1 requested, but $BUILT_MODULES is missing."
fi

cat > "$WORK_ROOT/run-modular-build.sh" <<'CHROOT_SCRIPT'
#!/usr/bin/env bash
set -uo pipefail
export HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig:/usr/local/share/pkgconfig:/usr/lib/pkgconfig:/usr/share/pkgconfig
export ACLOCAL_PATH=/usr/local/share/aclocal:/usr/share/aclocal
export LD_LIBRARY_PATH=/usr/local/lib:/usr/lib
export MAKEFLAGS="-j__JOBS__"
export NINJAFLAGS="-j__JOBS__"
cd /build/source-tree

# -n continues after modules that are intentionally non-buildable on this
# target. --clone obtains the maintained upstream list and dependency order.
set +e
./util/modular/build.sh \
    --clone \
    --autoresume /build/built.modules \
    -n \
    /usr \
    2>&1 | tee /build/logs/xorg-modular-build.log
status=${PIPESTATUS[0]}
set -e

ldconfig
exit "$status"
CHROOT_SCRIPT
sed -i "s/__JOBS__/$JOBS/g" "$WORK_ROOT/run-modular-build.sh"
chmod 0755 "$WORK_ROOT/run-modular-build.sh"

log "Building the maintained upstream modular list from source"
set +e
root_exec "$MERGED_ROOT" /bin/bash /build/run-modular-build.sh
BUILD_STATUS=$?
set -e

log "Recording source revisions"
{
    printf 'module\tcommit\tdescribe\tremote\n'
    while IFS= read -r gitdir; do
        repo="${gitdir%/.git}"
        rel="${repo#"$SOURCE_TREE"/}"
        commit="$(git -C "$repo" rev-parse HEAD 2>/dev/null || echo unknown)"
        describe="$(git -C "$repo" describe --always --dirty --tags 2>/dev/null || echo unknown)"
        remote="$(git -C "$repo" remote get-url origin 2>/dev/null || echo unknown)"
        printf '%s\t%s\t%s\t%s\n' \
            "$rel" "$commit" "$describe" "$remote"
    done < <(find "$SOURCE_TREE" -type d -name .git -print | sort)
} > "$MANIFEST"

{
    grep -Ei \
        '(^|[[:space:]])(failed|failure|error:|not found|cannot build|unsupported)' \
        "$BUILD_LOG" 2>/dev/null || true
} | awk '!seen[$0]++' > "$FAILURES"

cleanup
MOUNTS=()

log "Exporting source-built overlay into the ISO staging root"
safe_rm_tree "$STAGE_ROOT"
mkdir -p "$STAGE_ROOT"
rsync -aHAX --numeric-ids --delete "$BASE_ROOT/" "$STAGE_ROOT/"

# Apply overlay whiteouts before copying ordinary source-install files.
while IFS= read -r -d '' node; do
    rel="${node#"$UPPER_ROOT"/}"
    base="$(basename "$rel")"
    parent="$(dirname "$rel")"
    if [[ "$base" == .wh.* ]]; then
        rm -rf "$STAGE_ROOT/$parent/${base#.wh.}"
        rm -f "$node"
    elif [[ -c "$node" ]]; then
        major="$(stat -c %t "$node")"
        minor="$(stat -c %T "$node")"
        if [[ "$major" == 0 && "$minor" == 0 ]]; then
            rm -rf "$STAGE_ROOT/$rel"
            rm -f "$node"
        fi
    fi
done < <(
    find "$UPPER_ROOT" -xdev \( -name '.wh.*' -o -type c \) -print0
)

rsync -aHAX --numeric-ids \
    --exclude='/.wh.*' \
    --exclude='/**/.wh.*' \
    --exclude='/var/cache/pacman/***' \
    --exclude='/var/log/pacman.log' \
    --exclude='/build' \
    --exclude='/build/***' \
    "$UPPER_ROOT/" "$STAGE_ROOT/"

# Restore the original runtime package database. Build tools were installed only
# in DEPS_ROOT and must never leak into the ISO stage.
rsync -aHAX --numeric-ids --delete \
    "$BASE_ROOT/var/lib/pacman/" "$STAGE_ROOT/var/lib/pacman/"

log "Finding package records for paths replaced by source installs"
declare -A OWNERS=()
while IFS= read -r -d '' path; do
    rel="/${path#"$UPPER_ROOT"/}"
    case "$rel" in
        /usr/bin/*|/usr/sbin/*|/usr/lib/*|/usr/include/*|/usr/share/X11/*|/usr/share/pkgconfig/*)
            owner="$(
                chroot "$BASE_ROOT" /usr/bin/pacman -Qo "$rel" 2>/dev/null |
                sed -n 's/.* is owned by \([^ ]*\) .*/\1/p' |
                head -n1
            )"
            [[ -n "$owner" ]] && OWNERS["$owner"]=1
            ;;
    esac
done < <(
    find "$UPPER_ROOT/usr" -xdev \( -type f -o -type l \) -print0 2>/dev/null
)

printf '%s\n' "${!OWNERS[@]}" | sed '/^$/d' | sort > "$OWNERS_FILE"

if [[ -s "$OWNERS_FILE" ]]; then
    log "Removing replaced binary packages from staged root"
    mapfile -t owner_packages < "$OWNERS_FILE"
    installed=()
    for pkg in "${owner_packages[@]}"; do
        if pacman --root "$STAGE_ROOT" -Q "$pkg" >/dev/null 2>&1; then
            installed+=("$pkg")
        fi
    done
    if ((${#installed[@]})); then
        # Remove the package files as well as their database records. Dependency
        # checks and scriptlets are disabled because this is an offline staging
        # tree, not a running system. The source-build overlay is reapplied
        # immediately afterward so every removed X.Org path comes back from the
        # upstream source install rather than from an Arch binary package.
        pacman --root "$STAGE_ROOT" -Rdd --noscriptlet --noconfirm \
            "${installed[@]}"

        rsync -aHAX --numeric-ids \
            --exclude='/.wh.*' \
            --exclude='/**/.wh.*' \
            --exclude='/var/cache/pacman/***' \
            --exclude='/var/log/pacman.log' \
            --exclude='/build' \
            --exclude='/build/***' \
            "$UPPER_ROOT/" "$STAGE_ROOT/"
    fi
fi

SOURCE_META="$STAGE_ROOT/usr/share/hardened-arch/source-build"
mkdir -p "$SOURCE_META"
install -m 0644 "$MANIFEST" \
    "$SOURCE_META/xorg-source-manifest.tsv"
install -m 0644 "$FAILURES" \
    "$SOURCE_META/xorg-module-failures.txt"
install -m 0644 "$OWNERS_FILE" \
    "$SOURCE_META/xorg-replaced-package-records.txt"
if [[ -f "$BUILT_MODULES" ]]; then
    install -m 0644 "$BUILT_MODULES" \
        "$SOURCE_META/xorg-built.modules"
fi
printf '%s\n' "$XSERVER_TAG" > "$SOURCE_META/xserver-version"
printf '%s\n' "$(date -u +%FT%TZ)" > "$SOURCE_META/built-utc"
printf '%s\n' "upstream-xorg-util-modular" > "$SOURCE_META/build-method"

log "Verifying staged X.Org runtime"
mount_bind /dev "$STAGE_ROOT/dev"
mount_bind /proc "$STAGE_ROOT/proc"
mount_bind /sys "$STAGE_ROOT/sys"

{
    echo "===== SOURCE BUILD IDENTITY ====="
    cat "$SOURCE_META/xserver-version"
    cat "$SOURCE_META/build-method"

    echo
    echo "===== REQUIRED FILES ====="
    required_files=(
        /usr/bin/Xorg
        /usr/bin/Xwayland
        /usr/lib/xorg/modules/drivers/modesetting_drv.so
        /usr/lib/libX11.so
        /usr/share/X11/xkb
    )
    for rel in "${required_files[@]}"; do
        if [[ -e "$STAGE_ROOT$rel" || -L "$STAGE_ROOT$rel" ]]; then
            printf 'OK: %s\n' "$rel"
        else
            printf 'MISSING: %s\n' "$rel"
        fi
    done

    echo
    echo "===== XORG VERSION ====="
    root_exec "$STAGE_ROOT" Xorg -version 2>&1 || true

    echo
    echo "===== XORG ABI LOAD PROBE ====="
    mkdir -p "$STAGE_ROOT/tmp"
    cat > "$STAGE_ROOT/tmp/xorg-source-abi.conf" <<'EOF'
Section "Device"
    Identifier "SourceABIProbe"
    Driver "modesetting"
EndSection
Section "Screen"
    Identifier "SourceABIProbeScreen"
    Device "SourceABIProbe"
EndSection
EOF
    rm -f \
        "$STAGE_ROOT/tmp/Xorg.source-abi.log" \
        "$STAGE_ROOT/tmp/Xorg.source-abi.stdout"
    timeout 8 chroot "$STAGE_ROOT" Xorg :99 \
        -config /tmp/xorg-source-abi.conf \
        -logfile /tmp/Xorg.source-abi.log \
        -nolisten tcp \
        -novtswitch \
        -sharevts \
        >"$STAGE_ROOT/tmp/Xorg.source-abi.stdout" 2>&1 || true
    grep -Ei \
        'X.Org X Server|Module ABI versions|Module modesetting|compiled for|module version|Module class|ABI class|ABI mismatch|Failed to load|undefined symbol|not found' \
        "$STAGE_ROOT/tmp/Xorg.source-abi.log" \
        "$STAGE_ROOT/tmp/Xorg.source-abi.stdout" \
        2>/dev/null || true

    echo
    echo "===== PACKAGE OWNERSHIP ====="
    if chroot "$STAGE_ROOT" /usr/bin/pacman -Qo /usr/bin/Xorg 2>&1; then
        echo "ERROR: /usr/bin/Xorg is still package-owned"
    else
        echo "OK: /usr/bin/Xorg is not owned by a staged binary package"
    fi

    echo
    echo "===== MODESETTING LINKER CHECK ====="
    root_exec "$STAGE_ROOT" \
        ldd /usr/lib/xorg/modules/drivers/modesetting_drv.so 2>&1

    echo
    echo "===== ALL XORG MODULE LINKER FAILURES ====="
    missing=0
    while IFS= read -r -d '' module; do
        rel="/${module#"$STAGE_ROOT"/}"
        output="$(root_exec "$STAGE_ROOT" ldd "$rel" 2>&1 || true)"
        if grep -q 'not found' <<<"$output"; then
            printf '\n%s\n%s\n' "$rel" "$output"
            missing=1
        fi
    done < <(
        find "$STAGE_ROOT/usr/lib/xorg/modules" \
            -type f -name '*.so' -print0
    )
    ((missing == 0)) && echo "NONE"

    echo
    echo "===== BROKEN SYMLINKS ====="
    broken=0
    while IFS= read -r -d '' link; do
        printf 'BROKEN: %s -> %s\n' \
            "${link#"$STAGE_ROOT"}" "$(readlink "$link")"
        broken=1
    done < <(
        find "$STAGE_ROOT/usr" -xdev -type l \
            ! -exec test -e {} \; -print0
    )
    ((broken == 0)) && echo "NONE"

    echo
    echo "===== BUILT MODULE COUNT ====="
    if [[ -f "$BUILT_MODULES" ]]; then
        awk 'NF && $1 !~ /^#/' "$BUILT_MODULES" |
            sort -u | wc -l
    else
        echo 0
    fi

    echo
    echo "===== UPSTREAM BUILD EXIT STATUS ====="
    echo "$BUILD_STATUS"
} | tee "$VERIFY_LOG"

cleanup
MOUNTS=()

required_missing=0
for rel in \
    /usr/bin/Xorg \
    /usr/bin/Xwayland \
    /usr/lib/xorg/modules/drivers/modesetting_drv.so \
    /usr/lib/libX11.so \
    /usr/share/X11/xkb
do
    [[ -e "$STAGE_ROOT$rel" || -L "$STAGE_ROOT$rel" ]] ||
        required_missing=1
done

# Direct host-side check against the staged root.
if chroot "$STAGE_ROOT" /usr/bin/ldd \
    /usr/lib/xorg/modules/drivers/modesetting_drv.so 2>&1 |
    grep -q 'not found'
then
    die "The staged modesetting driver has unresolved libraries."
fi

if chroot "$STAGE_ROOT" /usr/bin/pacman -Qo /usr/bin/Xorg >/dev/null 2>&1; then
    die "The staged Xorg binary is still recorded as package-owned."
fi

if grep -Eiq \
    'ABI mismatch|module ABI major version.*doesn.t match|undefined symbol|Failed to load module "modesetting"' \
    "$VERIFY_LOG"
then
    die "The source-built modesetting module failed the X.Org ABI load probe."
fi

built_count=0
if [[ -f "$BUILT_MODULES" ]]; then
    built_count="$(
        awk 'NF && $1 !~ /^#/' "$BUILT_MODULES" |
        sort -u | wc -l
    )"
fi

if ((required_missing)); then
    die "Core X.Org source build is incomplete. See $BUILD_LOG and $VERIFY_LOG"
fi

if [[ "$STRICT_ALL" == 1 ]]; then
    ((BUILD_STATUS == 0)) ||
        die "At least one upstream module failed and STRICT_ALL=1."
    ((built_count >= EXPECTED_MODULES)) ||
        die "Only $built_count modules were recorded; expected at least $EXPECTED_MODULES."
fi

chown -R "$OWNER:$OWNER" "$WORK_ROOT/reports" "$WORK_ROOT/logs" \
    2>/dev/null || true
printf '\nSOURCE X.ORG STAGE COMPLETE\n'
printf 'Stage root:       %s\n' "$STAGE_ROOT"
printf 'Build log:        %s\n' "$BUILD_LOG"
printf 'Verification:     %s\n' "$VERIFY_LOG"
printf 'Built modules:    %s\n' "$built_count"
printf 'Upstream status:  %s\n' "$BUILD_STATUS"
if ((built_count < EXPECTED_MODULES)); then
    printf 'NOTE: The maintained list includes architecture-specific and retired modules.\n'
    printf '      Every module was attempted; inspect %s for skips/failures.\n' "$FAILURES"
fi
printf '\nISO builder runtime root:\n  %s\n' "$STAGE_ROOT"
