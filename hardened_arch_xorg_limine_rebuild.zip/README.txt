Hardened Arch source X.Org + Limine rebuild
==========================================

Run these files in order from the directory containing them.

1. Build and stage the X.Org stack from upstream source
-------------------------------------------------------

    chmod +x rebuild_xorg_source_stack.sh
    sudo ./rebuild_xorg_source_stack.sh

Default source-built runtime stage:

    ~/xorg-source-stage/rootfs

Build logs and provenance records:

    ~/xorg-source-build/logs/
    ~/xorg-source-build/reports/
    ~/xorg-source-stage/rootfs/usr/share/hardened-arch/source-build/

The script uses pacman only inside a disposable dependency root. It then builds
X.Org's maintained modular list into an overlay, removes any replaced Arch X.Org
binary packages from the exported runtime stage, and reapplies the source
install. The ISO staging tree therefore does not quietly fall back to package
files for the X.Org components that were rebuilt.

An interrupted build can be resumed with:

    sudo RESUME=1 ./rebuild_xorg_source_stack.sh

2. Build Limine from official source
------------------------------------

    chmod +x build_limine_from_source.sh
    ./build_limine_from_source.sh

Default output:

    ~/bootloader-build/limine/BOOTX64.EFI

The default source tag is Limine v12.3.2. Override it explicitly when needed:

    LIMINE_REF=v12.3.2 JOBS=4 ./build_limine_from_source.sh

3. Patch the existing ISO builder
---------------------------------

    chmod +x patch_hardened_iso_for_limine.py
    ./patch_hardened_iso_for_limine.py

The patcher creates a timestamped backup of:

    ~/build_hardened_arch_iso.py

It changes the builder's default runtime root to:

    ~/xorg-source-stage/rootfs

It also replaces rEFInd ESP generation with source-built Limine while leaving
unrelated live-media and physical-boot initramfs repairs intact.

4. Build the ISO
----------------

Use the existing builder command, for example:

    sudo python3 ~/build_hardened_arch_iso.py \
        --version 1.10-alpha \
        --force \
        --keep-work

X.Org validation performed by the script
-----------------------------------------

- /usr/bin/Xorg exists.
- /usr/bin/Xwayland exists.
- modesetting_drv.so exists and resolves every runtime library.
- Xorg loads modesetting far enough to report the server and video-driver ABI.
- No X.Org module has an unresolved shared-library dependency.
- No broken symlinks remain under staged /usr.
- /usr/bin/Xorg is not owned by a binary package in the staged pacman database.
- Source URLs, commits, successful modules, failures, and build time are stored
  in the final staged root.

The official modular list contains more than 200 projects. Every listed module
is attempted. Several old drivers are architecture-specific and cannot build on
x86_64; those failures are recorded rather than hidden. STRICT_ALL=1 is
available, but it will make legitimate target-specific failures fatal:

    sudo STRICT_ALL=1 EXPECTED_MODULES=230 ./rebuild_xorg_source_stack.sh

Useful X.Org overrides
----------------------

    sudo BASE_ROOT=~/runtime-package-root \
         STAGE_ROOT=~/xorg-source-stage/rootfs \
         XSERVER_TAG=xorg-server-21.1.24 \
         JOBS=4 \
         ./rebuild_xorg_source_stack.sh

Useful patcher overrides
------------------------

    ./patch_hardened_iso_for_limine.py \
        --builder ~/build_hardened_arch_iso.py \
        --runtime-root ~/xorg-source-stage/rootfs \
        --limine-dir ~/bootloader-build/limine \
        --theme-dir ~/boot-theme-build/refind/hardened-arch

Boot-menu decision
------------------

The old rEFInd path is deliberately removed. rEFInd can skin a full-screen
background, icons, and square selection tiles, but it cannot reproduce the
mockup's wide glowing selected row inside a translucent vertical panel.

The Limine replacement uses the existing Hardened Arch background, panel, and
shield assets when available; a translucent graphical menu region; a red and
gray palette; a default live entry; and an expanded Advanced Options directory
for installation, recovery, and verbose diagnostic boot.

Do not rerun the old rEFInd-specific physical-boot repair script after applying
the Limine patch. Its live-init changes are preserved, but its rEFInd-specific
audit assumptions no longer apply.
