#!/usr/bin/env bash
set -Eeuo pipefail

OLD_ISO=/home/corbett/hardened-arch-1.10-alpha-x86_64.iso
EXTRACT=/home/corbett/hardened-rootfs-verified
WORK=/home/corbett/hardened-fast-repack
NEW_SFS="$WORK/rootfs.sfs"
NEW_ISO=/home/corbett/hardened-arch-1.10-alpha-x86_64-login-accessibility-test.iso
VERIFY_MNT=/mnt/hardened-fast-repack-check
REPAIR_SCRIPT="$(dirname "$0")/01_repair_login_stack.sh"

section() {
    echo
    echo "===== $* ====="
}

if (( EUID != 0 )); then
    echo "Run this script with sudo."
    exit 1
fi

for command_name in \
    mksquashfs \
    sha256sum \
    unsquashfs \
    xorriso
do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "FAIL: Missing host command: $command_name"
        exit 1
    }
done

test -f "$OLD_ISO" || {
    echo "FAIL: Original ISO missing: $OLD_ISO"
    exit 1
}

test -d "$EXTRACT/etc" || {
    echo "FAIL: Repaired extracted root missing: $EXTRACT"
    exit 1
}

section "FINAL EXTRACTED-ROOT GATE"

"$REPAIR_SCRIPT" --audit

section "PREPARE OUTPUT"

install -d -m 0755 "$WORK"
rm -f "$NEW_SFS" "$NEW_ISO"

section "CREATE ONLY A NEW ROOTFS.SFS"

mksquashfs \
    "$EXTRACT" \
    "$NEW_SFS" \
    -comp zstd \
    -b 1048576 \
    -noappend \
    -no-progress

unsquashfs -s "$NEW_SFS"

ROOTFS_HASH=$(sha256sum "$NEW_SFS" | awk '{print $1}')
ROOTFS_SIZE=$(stat -c '%s' "$NEW_SFS")

printf '%s  rootfs.sfs\n' "$ROOTFS_HASH" \
    > "$WORK/rootfs.sfs.sha256"

echo "New rootfs SHA256: $ROOTFS_HASH"
echo "New rootfs size:   $ROOTFS_SIZE"

section "CLONE ORIGINAL BOOTABLE ISO AND REPLACE ROOTFS"

xorriso \
    -indev "$OLD_ISO" \
    -outdev "$NEW_ISO" \
    -overwrite on \
    -map "$NEW_SFS" /hardened/rootfs.sfs \
    -map "$WORK/rootfs.sfs.sha256" /hardened/rootfs.sfs.sha256 \
    -boot_image any replay \
    -commit

section "VERIFY NEW ISO BOOT RECORD"

xorriso \
    -indev "$NEW_ISO" \
    -report_el_torito plain

section "VERIFY MAPPED ROOTFS BYTE-FOR-BYTE"

umount "$VERIFY_MNT" 2>/dev/null || true
install -d -m 0755 "$VERIFY_MNT"
mount -o loop,ro "$NEW_ISO" "$VERIFY_MNT"

MAPPED_HASH=$(
    sha256sum "$VERIFY_MNT/hardened/rootfs.sfs" |
        awk '{print $1}'
)

if [[ "$MAPPED_HASH" != "$ROOTFS_HASH" ]]; then
    echo "FAIL: rootfs hash changed while writing the ISO"
    umount "$VERIFY_MNT"
    exit 1
fi

echo "PASS: mapped rootfs SHA256 matches"

section "VERIFY CRITICAL FILES WITHOUT FULL EXTRACTION"

SFS="$VERIFY_MNT/hardened/rootfs.sfs"

for FILE in \
    etc/sddm.conf.d/20-hardened-wayland.conf \
    usr/lib/sddm/sddm-helper \
    usr/lib/sddm/sddm-helper-start-wayland \
    usr/bin/unix_chkpwd \
    usr/share/sddm/themes/hardened-accessible/Main.qml \
    usr/local/libexec/hardened-sddm-orca \
    var/lib/sddm/.config/systemd/user/hardened-sddm-orca.service
do
    if unsquashfs -ll "$SFS" "$FILE" 2>/dev/null |
        grep -Fq "$FILE"
    then
        echo "PASS: /$FILE"
    else
        echo "FAIL: /$FILE"
        umount "$VERIFY_MNT"
        exit 1
    fi
done

echo
echo "--- Effective SDDM configuration ---"
unsquashfs -cat \
    "$SFS" \
    etc/sddm.conf.d/20-hardened-wayland.conf

echo
echo "--- Accessible theme markers ---"
unsquashfs -cat \
    "$SFS" \
    usr/share/sddm/themes/hardened-accessible/Main.qml |
    grep -E \
        'HARDENED_ACCESSIBLE_GREETER_V1|Meta\+=|Meta\+-|Meta\+0|Zoom \+|Zoom −'

umount "$VERIFY_MNT"

section "FINAL CHECKSUM"

sha256sum "$NEW_ISO"

echo
echo "========================================"
echo "FAST TEST ISO: PASS"
echo "$NEW_ISO"
echo
echo "The original ISO was not modified."
echo "No kernel, KDE, Qt, or toolchain was rebuilt."
echo "========================================"
