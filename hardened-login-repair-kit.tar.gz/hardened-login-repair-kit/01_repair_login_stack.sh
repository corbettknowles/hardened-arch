#!/usr/bin/env bash
set -Eeuo pipefail

MODE="${1:---audit}"

case "$MODE" in
    --audit|--apply) ;;
    *)
        echo "Usage: $0 [--audit|--apply]"
        exit 2
        ;;
esac

STAGE=/home/corbett/xorg-source-stage/rootfs
EXTRACT=/home/corbett/hardened-rootfs-verified
CACHE=/home/corbett/hardened-package-cache
ARCHIVE_BASE=/home/corbett/hardened-repair-archive
STAMP=$(date +%Y%m%d-%H%M%S)
ARCHIVE="$ARCHIVE_BASE/$STAMP"

ROOTS=(
    "stage:$STAGE"
    "extracted:$EXTRACT"
)

REQUIRED_COMMANDS=(
    awk
    bsdtar
    grep
    pacman
    readelf
    sha256sum
    stat
    strings
)

pass_count=0
fail_count=0
warn_count=0

pass() {
    echo "PASS: $*"
    pass_count=$((pass_count + 1))
}

fail() {
    echo "FAIL: $*"
    fail_count=$((fail_count + 1))
}

warn() {
    echo "WARN: $*"
    warn_count=$((warn_count + 1))
}

section() {
    echo
    echo "===== $* ====="
}

for command_name in "${REQUIRED_COMMANDS[@]}"; do
    command -v "$command_name" >/dev/null 2>&1 ||
        fail "Host command missing: $command_name"
done

archive_root_paths() {
    local label=$1
    local root=$2
    local list_file="$ARCHIVE/$label.paths"

    : > "$list_file"

    local candidates=(
        etc/sddm.conf
        etc/sddm.conf.d/20-hardened-wayland.conf
        etc/pam.d/sddm
        etc/pam.d/sddm-autologin
        etc/pam.d/sddm-greeter
        usr/bin/sddm
        usr/bin/sddm-greeter
        usr/bin/sddm-greeter-qt6
        usr/bin/unix_chkpwd
        usr/lib/sddm
        usr/lib/qt6/plugins/wayland-shell-integration
        usr/lib/qt6/qml/org/kde/layershell
        usr/lib/libLayerShellQtInterface.so
        usr/lib/libLayerShellQtInterface.so.6
        usr/share/sddm/themes/hardened-accessible
        usr/local/libexec/hardened-sddm-orca
        var/lib/sddm/.config/systemd/user/hardened-sddm-orca.service
        var/lib/sddm/.config/systemd/user/default.target.wants/hardened-sddm-orca.service
    )

    local path
    for path in "${candidates[@]}"; do
        if [[ -e "$root/$path" || -L "$root/$path" ]]; then
            printf '%s\n' "$path" >> "$list_file"
        fi
    done

    if [[ -s "$list_file" ]]; then
        tar \
            --acls \
            --xattrs \
            --numeric-owner \
            -cpf "$ARCHIVE/$label-before.tar" \
            -C "$root" \
            -T "$list_file"

        sha256sum "$ARCHIVE/$label-before.tar" \
            > "$ARCHIVE/$label-before.tar.sha256"

        pass "Archived every pre-existing path that will be overwritten in $label"
    else
        warn "No pre-existing target paths needed archiving in $label"
    fi
}

write_accessible_theme() {
    local root=$1
    local theme="$root/usr/share/sddm/themes/hardened-accessible"

    install -d -m 0755 "$theme"

    cat > "$theme/metadata.desktop" <<'THEME_METADATA'
[SddmGreeterTheme]
Name=Hardened Accessible
Description=Accessible Hardened Arch login greeter with local zoom controls
Author=Hardened Arch
License=MIT
Type=sddm-theme
Version=1.0
MainScript=Main.qml
ConfigFile=theme.conf
Theme-Id=hardened-accessible
Theme-API=2.0
THEME_METADATA

    cat > "$theme/theme.conf" <<'THEME_CONFIG'
[General]
defaultZoom=1.35
THEME_CONFIG

    cat > "$theme/Main.qml" <<'QML'
/* HARDENED_ACCESSIBLE_GREETER_V1 */
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: root

    width: 1280
    height: 720
    color: "#10151c"
    focus: true

    property real zoomLevel: 1.35
    property string statusText: "Enter the password for hardened."
    property bool loginBusy: false

    function zoomIn() {
        zoomLevel = Math.min(2.25, Math.round((zoomLevel + 0.15) * 100) / 100)
    }

    function zoomOut() {
        zoomLevel = Math.max(1.0, Math.round((zoomLevel - 0.15) * 100) / 100)
    }

    function zoomReset() {
        zoomLevel = 1.35
    }

    function submitLogin() {
        if (loginBusy || username.text.length === 0) {
            return
        }

        loginBusy = true
        statusText = "Signing in…"
        sddm.login(username.text, password.text, session.currentIndex)
    }

    Shortcut {
        sequence: "Meta+="
        context: Qt.ApplicationShortcut
        onActivated: root.zoomIn()
    }

    Shortcut {
        sequence: "Meta++"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomIn()
    }

    Shortcut {
        sequence: "Meta+-"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomOut()
    }

    Shortcut {
        sequence: "Meta+0"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomReset()
    }

    Shortcut {
        sequence: "F6"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomOut()
    }

    Shortcut {
        sequence: "F7"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomIn()
    }

    Shortcut {
        sequence: "F8"
        context: Qt.ApplicationShortcut
        onActivated: root.zoomReset()
    }

    Rectangle {
        anchors.fill: parent
        color: "#10151c"

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: 22
            text: "Hardened Arch Linux"
            color: "white"
            font.pixelSize: 30
            font.bold: true
            Accessible.name: text
            Accessible.role: Accessible.StaticText
        }

        Rectangle {
            id: panel

            anchors.centerIn: parent
            width: Math.max(430, Math.min(700, root.width / root.zoomLevel - 60))
            height: Math.max(460, Math.min(590, root.height / root.zoomLevel - 60))
            scale: root.zoomLevel
            transformOrigin: Item.Center
            radius: 18
            color: "#eaf0f6"
            border.width: 2
            border.color: "#6f8194"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 28
                spacing: 14

                Label {
                    Layout.alignment: Qt.AlignHCenter
                    text: "Accessible Login"
                    font.pixelSize: 28
                    font.bold: true
                    color: "#10151c"
                    Accessible.name: text
                }

                Label {
                    Layout.fillWidth: true
                    text: "Zoom: Meta+= / Meta+- / Meta+0     F7 / F6 / F8"
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                    font.pixelSize: 16
                    color: "#263747"
                    Accessible.name: text
                }

                Label {
                    text: "Username"
                    font.pixelSize: 18
                    color: "#10151c"
                    Accessible.name: text
                }

                TextField {
                    id: username
                    Layout.fillWidth: true
                    text: "hardened"
                    selectByMouse: true
                    font.pixelSize: 22
                    Accessible.name: "Username"
                    Accessible.description: "Live system username"
                    onAccepted: password.forceActiveFocus()
                }

                Label {
                    text: "Password"
                    font.pixelSize: 18
                    color: "#10151c"
                    Accessible.name: text
                }

                TextField {
                    id: password
                    Layout.fillWidth: true
                    echoMode: TextInput.Password
                    selectByMouse: true
                    font.pixelSize: 22
                    Accessible.name: "Password"
                    Accessible.description: "Live system password"
                    onAccepted: root.submitLogin()
                }

                Label {
                    text: "Desktop session"
                    font.pixelSize: 18
                    color: "#10151c"
                    Accessible.name: text
                }

                ComboBox {
                    id: session
                    Layout.fillWidth: true
                    model: sessionModel
                    textRole: "name"
                    currentIndex: sessionModel.lastIndex >= 0
                        ? sessionModel.lastIndex
                        : 0
                    font.pixelSize: 20
                    Accessible.name: "Desktop session"
                }

                Button {
                    Layout.fillWidth: true
                    text: loginBusy ? "Signing in…" : "Sign In"
                    enabled: !loginBusy
                    font.pixelSize: 22
                    Accessible.name: text
                    onClicked: root.submitLogin()
                }

                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 12

                    Button {
                        text: "Zoom −"
                        font.pixelSize: 18
                        Accessible.name: "Decrease login magnification"
                        onClicked: root.zoomOut()
                    }

                    Button {
                        text: "Reset"
                        font.pixelSize: 18
                        Accessible.name: "Reset login magnification"
                        onClicked: root.zoomReset()
                    }

                    Button {
                        text: "Zoom +"
                        font.pixelSize: 18
                        Accessible.name: "Increase login magnification"
                        onClicked: root.zoomIn()
                    }
                }

                Label {
                    Layout.fillWidth: true
                    text: root.statusText
                    wrapMode: Text.WordWrap
                    horizontalAlignment: Text.AlignHCenter
                    font.pixelSize: 17
                    color: "#263747"
                    Accessible.name: text
                }
            }
        }

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 18
            spacing: 14

            Button {
                text: "Restart"
                enabled: sddm.canReboot
                Accessible.name: "Restart computer"
                onClicked: sddm.reboot()
            }

            Button {
                text: "Shut Down"
                enabled: sddm.canPowerOff
                Accessible.name: "Shut down computer"
                onClicked: sddm.powerOff()
            }
        }
    }

    Connections {
        target: sddm

        function onLoginFailed() {
            root.loginBusy = false
            root.statusText = "Login failed. Check the password and try again."
            password.selectAll()
            password.forceActiveFocus()
        }

        function onLoginSucceeded() {
            root.statusText = "Login accepted. Starting Plasma Wayland…"
        }
    }

    Component.onCompleted: password.forceActiveFocus()
}
QML

    chmod 0644 \
        "$theme/Main.qml" \
        "$theme/metadata.desktop" \
        "$theme/theme.conf"
}

write_sddm_config() {
    local root=$1
    local cfg="$root/etc/sddm.conf.d/20-hardened-wayland.conf"

    install -d -m 0755 "$(dirname "$cfg")"

    cat > "$cfg" <<'SDDM_CONFIG'
[General]
DisplayServer=wayland
GreeterEnvironment=QT_WAYLAND_SHELL_INTEGRATION=layer-shell,QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1,QT_ACCESSIBILITY=1,NO_AT_BRIDGE=0
InputMethod=

[Theme]
Current=hardened-accessible

[Users]
MinimumUid=1000
MaximumUid=60000
RememberLastUser=false
RememberLastSession=false

[Autologin]
Relogin=false
User=
Session=

[Wayland]
CompositorCommand=/usr/bin/kwin_wayland --drm --no-lockscreen --no-global-shortcuts --locale1
SessionCommand=/usr/share/sddm/scripts/wayland-session
SDDM_CONFIG

    chmod 0644 "$cfg"
}

write_orca_greeter_service() {
    local root=$1
    local helper="$root/usr/local/libexec/hardened-sddm-orca"
    local unit_dir="$root/var/lib/sddm/.config/systemd/user"
    local unit="$unit_dir/hardened-sddm-orca.service"
    local wants="$unit_dir/default.target.wants"

    install -d -m 0755 \
        "$(dirname "$helper")" \
        "$unit_dir" \
        "$wants" \
        "$root/var/lib/sddm/.local/state"

    cat > "$helper" <<'ORCA_HELPER'
#!/usr/bin/env bash
set -Eeuo pipefail

uid=$(id -u)

export HOME=/var/lib/sddm
export XDG_RUNTIME_DIR="/run/user/$uid"
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
export QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1
export QT_ACCESSIBILITY=1
export NO_AT_BRIDGE=0

for _ in $(seq 1 300); do
    if [[ -S "$XDG_RUNTIME_DIR/bus" ]]; then
        break
    fi
    sleep 0.1
done

if [[ ! -S "$XDG_RUNTIME_DIR/bus" ]]; then
    echo "SDDM Orca: user D-Bus socket did not appear" >&2
    exit 1
fi

wayland_socket=""

for _ in $(seq 1 300); do
    for candidate in "$XDG_RUNTIME_DIR"/wayland-*; do
        if [[ -S "$candidate" ]]; then
            wayland_socket=$candidate
            break 2
        fi
    done
    sleep 0.1
done

if [[ -z "$wayland_socket" ]]; then
    echo "SDDM Orca: Wayland socket did not appear" >&2
    exit 1
fi

export WAYLAND_DISPLAY="${wayland_socket##*/}"

mkdir -p \
    "$HOME/.config" \
    "$HOME/.cache" \
    "$HOME/.local/share/orca" \
    "$HOME/.local/state"

exec /usr/bin/orca --replace
ORCA_HELPER

    chmod 0755 "$helper"

    cat > "$unit" <<'ORCA_UNIT'
[Unit]
Description=Hardened SDDM Greeter Screen Reader
ConditionPathExists=/usr/bin/orca
After=dbus.service

[Service]
Type=simple
ExecStart=/usr/local/libexec/hardened-sddm-orca
Restart=on-failure
RestartSec=2

[Install]
WantedBy=default.target
ORCA_UNIT

    chmod 0644 "$unit"

    ln -sfn \
        ../hardened-sddm-orca.service \
        "$wants/hardened-sddm-orca.service"

    local sddm_uid
    local sddm_gid

    sddm_uid=$(awk -F: '$1=="sddm" {print $3}' "$root/etc/passwd")
    sddm_gid=$(awk -F: '$1=="sddm" {print $4}' "$root/etc/passwd")

    if [[ -z "$sddm_uid" || -z "$sddm_gid" ]]; then
        fail "Cannot determine sddm UID/GID in $root"
        return 1
    fi

    chown -R "$sddm_uid:$sddm_gid" "$root/var/lib/sddm"
    chmod 0750 "$root/var/lib/sddm"
}

find_latest_package() {
    local package_name=$1

    find "$CACHE" \
        -maxdepth 1 \
        -type f \
        -name "${package_name}-*.pkg.tar.zst" \
        -printf '%T@ %p\n' |
        sort -nr |
        head -n 1 |
        cut -d' ' -f2-
}

extract_package_payload() {
    local package_file=$1
    local root=$2

    bsdtar \
        -xpf "$package_file" \
        -C "$root" \
        --exclude=.BUILDINFO \
        --exclude=.MTREE \
        --exclude=.PKGINFO \
        --exclude=.INSTALL \
        --exclude=.CHANGELOG
}

restore_signed_payload() {
    install -d -m 0755 "$CACHE"

    section "DOWNLOAD AND VERIFY SIGNED ARCH PACKAGES"

    pacman \
        -Sw \
        --noconfirm \
        --cachedir "$CACHE" \
        sddm \
        pam \
        layer-shell-qt

    local sddm_pkg
    local pam_pkg
    local layer_pkg

    sddm_pkg=$(find_latest_package sddm)
    pam_pkg=$(find_latest_package pam)
    layer_pkg=$(find_latest_package layer-shell-qt)

    [[ -n "$sddm_pkg" ]] || {
        fail "Downloaded sddm package was not found"
        return 1
    }

    [[ -n "$pam_pkg" ]] || {
        fail "Downloaded pam package was not found"
        return 1
    }

    [[ -n "$layer_pkg" ]] || {
        fail "Downloaded layer-shell-qt package was not found"
        return 1
    }

    {
        echo "sddm=$sddm_pkg"
        echo "pam=$pam_pkg"
        echo "layer-shell-qt=$layer_pkg"
        sha256sum "$sddm_pkg" "$pam_pkg" "$layer_pkg"
        pacman -Qip "$sddm_pkg" "$pam_pkg" "$layer_pkg"
    } | tee "$ARCHIVE/package-record.txt"

    local item
    local label
    local root

    for item in "${ROOTS[@]}"; do
        label=${item%%:*}
        root=${item#*:}

        section "RESTORE SIGNED PAYLOAD: $label"

        extract_package_payload "$sddm_pkg" "$root"
        extract_package_payload "$layer_pkg" "$root"

        bsdtar \
            -xpf "$pam_pkg" \
            -C "$root" \
            usr/bin/unix_chkpwd

        pass "Restored official SDDM, layer-shell-qt, and unix_chkpwd payload in $label"
    done
}

audit_root() {
    local label=$1
    local root=$2

    section "AUDIT ROOT: $label"

    if [[ ! -d "$root/etc" ]]; then
        fail "$label root is missing: $root"
        return
    fi

    local required=(
        usr/bin/sddm
        usr/bin/sddm-greeter-qt6
        usr/lib/sddm/sddm-helper
        usr/lib/sddm/sddm-helper-start-wayland
        usr/lib/sddm/sddm-helper-start-x11user
        usr/share/sddm/scripts/wayland-session
        usr/bin/unix_chkpwd
        usr/bin/kwin_wayland
        usr/bin/orca
        usr/bin/speech-dispatcher
        usr/bin/espeak-ng
        usr/libexec/at-spi-bus-launcher
        usr/libexec/at-spi2-registryd
        usr/lib/qt6/plugins/wayland-shell-integration/liblayer-shell.so
        etc/sddm.conf.d/20-hardened-wayland.conf
        usr/share/sddm/themes/hardened-accessible/Main.qml
        usr/local/libexec/hardened-sddm-orca
        var/lib/sddm/.config/systemd/user/hardened-sddm-orca.service
    )

    local file
    for file in "${required[@]}"; do
        if [[ -e "$root/$file" || -L "$root/$file" ]]; then
            pass "$label: /$file"
        else
            fail "$label: /$file is missing"
        fi
    done

    if [[ -f "$root/usr/bin/unix_chkpwd" ]]; then
        local mode
        mode=$(stat -c '%a' "$root/usr/bin/unix_chkpwd")
        echo "unix_chkpwd mode: $mode"

        if (( (8#$mode & 8#6000) != 0 )); then
            pass "$label: unix_chkpwd has setuid or setgid privilege"
        else
            fail "$label: unix_chkpwd lacks setuid/setgid privilege"
        fi
    fi

    local cfg="$root/etc/sddm.conf.d/20-hardened-wayland.conf"

    if [[ -f "$cfg" ]]; then
        local tokens=(
            "DisplayServer=wayland"
            "QT_WAYLAND_SHELL_INTEGRATION=layer-shell"
            "QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1"
            "QT_ACCESSIBILITY=1"
            "NO_AT_BRIDGE=0"
            "Current=hardened-accessible"
            "CompositorCommand=/usr/bin/kwin_wayland --drm --no-lockscreen --no-global-shortcuts --locale1"
        )

        local token
        for token in "${tokens[@]}"; do
            if grep -Fqx "$token" "$cfg" ||
               grep -Fq "$token" "$cfg"; then
                pass "$label config: $token"
            else
                fail "$label config missing: $token"
            fi
        done
    fi

    if grep -RqsE \
        '^[[:space:]]*DisplayServer[[:space:]]*=[[:space:]]*x11' \
        "$root/etc/sddm.conf" \
        "$root/etc/sddm.conf.d" \
        2>/dev/null
    then
        fail "$label: an effective SDDM config still forces X11"
    else
        pass "$label: no SDDM configuration forces X11"
    fi

    local qml="$root/usr/share/sddm/themes/hardened-accessible/Main.qml"

    if [[ -f "$qml" ]]; then
        for token in \
            HARDENED_ACCESSIBLE_GREETER_V1 \
            'sequence: "Meta+="' \
            'sequence: "Meta+-"' \
            'sequence: "Meta+0"' \
            'text: "Zoom +"' \
            'text: "Zoom −"'
        do
            if grep -Fq "$token" "$qml"; then
                pass "$label theme marker: $token"
            else
                fail "$label theme missing marker: $token"
            fi
        done
    fi

    local orca_unit="$root/var/lib/sddm/.config/systemd/user/hardened-sddm-orca.service"
    local orca_link="$root/var/lib/sddm/.config/systemd/user/default.target.wants/hardened-sddm-orca.service"

    if [[ -f "$orca_unit" && -L "$orca_link" ]]; then
        pass "$label: pre-login Orca user service is enabled"
    else
        fail "$label: pre-login Orca user service is not enabled"
    fi

    for binary in \
        /usr/bin/sddm \
        /usr/bin/sddm-greeter-qt6 \
        /usr/lib/sddm/sddm-helper \
        /usr/lib/sddm/sddm-helper-start-wayland \
        /usr/bin/unix_chkpwd
    do
        if [[ -x "$root$binary" ]]; then
            local missing
            missing=$(
                chroot "$root" /usr/bin/ldd "$binary" 2>&1 |
                    grep 'not found' || true
            )

            if [[ -n "$missing" ]]; then
                echo "$missing"
                fail "$label: missing libraries for $binary"
            else
                pass "$label: libraries complete for $binary"
            fi
        fi
    done

    if [[ -x "$root/usr/bin/qmllint" && -f "$qml" ]]; then
        if chroot "$root" /usr/bin/qmllint \
            /usr/share/sddm/themes/hardened-accessible/Main.qml
        then
            pass "$label: qmllint accepted the accessible theme"
        else
            fail "$label: qmllint rejected the accessible theme"
        fi
    else
        warn "$label: qmllint is unavailable; marker checks were used"
    fi

    if [[ -f "$root/usr/lib/libatspi.so.0" ]]; then
        if readelf -d "$root/usr/lib/libatspi.so.0" |
            grep -q 'NEEDED.*libXRes'
        then
            pass "$label: AT-SPI remains linked to libXRes"
        else
            fail "$label: AT-SPI lost libXRes linkage"
        fi
    fi

    if [[ -x "$root/usr/libexec/at-spi-bus-launcher" ]]; then
        if strings "$root/usr/libexec/at-spi-bus-launcher" |
            grep -qx '/usr/bin/dbus-daemon'
        then
            pass "$label: AT-SPI uses /usr/bin/dbus-daemon"
        else
            fail "$label: AT-SPI has the wrong dbus-daemon path"
        fi
    fi

    if [[ "$label" == extracted ]]; then
        if chroot "$root" getent passwd hardened >/dev/null 2>&1; then
            chroot "$root" getent passwd hardened
            chroot "$root" passwd -S hardened
            pass "extracted: hardened account exists"
        else
            fail "extracted: hardened account is missing"
        fi
    fi
}

section "MODE"
echo "$MODE"

for item in "${ROOTS[@]}"; do
    label=${item%%:*}
    root=${item#*:}
    audit_root "$label" "$root"
done

if [[ "$MODE" == --audit ]]; then
    section "AUDIT SUMMARY"
    echo "PASS: $pass_count"
    echo "WARN: $warn_count"
    echo "FAIL: $fail_count"
    echo
    echo "No files were changed."
    echo "Run with --apply only after reviewing this audit."
    exit 0
fi

if (( EUID != 0 )); then
    echo "ERROR: --apply must be run with sudo."
    exit 1
fi

section "ARCHIVE BEFORE CHANGES"

install -d -m 0755 "$ARCHIVE"

for item in "${ROOTS[@]}"; do
    label=${item%%:*}
    root=${item#*:}
    archive_root_paths "$label" "$root"
done

{
    echo "Repair archive: $ARCHIVE"
    echo "Created: $(date --iso-8601=seconds)"
} > "$ARCHIVE/README.txt"

restore_signed_payload

for item in "${ROOTS[@]}"; do
    label=${item%%:*}
    root=${item#*:}

    section "WRITE EXPLICIT ACCESSIBILITY CONFIGURATION: $label"

    write_sddm_config "$root"
    write_accessible_theme "$root"
    write_orca_greeter_service "$root"

    pass "Wrote exact Wayland, magnifier, and Orca configuration in $label"
done

section "POST-CHANGE VERIFICATION"

pass_count=0
fail_count=0
warn_count=0

for item in "${ROOTS[@]}"; do
    label=${item%%:*}
    root=${item#*:}
    audit_root "$label" "$root"
done

{
    echo
    echo "POST-CHANGE RESULTS"
    echo "PASS: $pass_count"
    echo "WARN: $warn_count"
    echo "FAIL: $fail_count"
} | tee -a "$ARCHIVE/README.txt"

if (( fail_count > 0 )); then
    echo
    echo "REPAIR RESULT: FAIL"
    echo "Do not patch the builder or repack the ISO."
    exit 1
fi

echo
echo "========================================"
echo "LOGIN STACK REPAIR: PASS"
echo "Archive: $ARCHIVE"
echo "No original file was deleted."
echo "========================================"
