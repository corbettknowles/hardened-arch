#!/usr/bin/env python3
"""
Audit or patch only the known bad SDDM configuration in the Hardened Arch
builder, then install a final pre-squashfs verification gate.

Default mode is --audit. Nothing is changed without --apply.
"""

from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import os
from pathlib import Path
import re
import shutil
import sys

BUILDER = Path("/home/corbett/build_hardened_arch_iso.py")
STAGE = Path("/home/corbett/xorg-source-stage/rootfs")
ARCHIVE_BASE = Path("/home/corbett/hardened-repair-archive")

VERIFY_FUNCTION = r