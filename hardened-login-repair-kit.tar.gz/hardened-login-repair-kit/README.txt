HARDENED ARCH LOGIN REPAIR KIT
==============================

Purpose
-------
1. Restore the signed Arch SDDM helper payload and the privileged PAM helper.
2. Switch the SDDM greeter to KWin Wayland.
3. Add a self-contained login-screen zoom theme:
      Meta+=  zoom in
      Meta+-  zoom out
      Meta+0  reset
      F7      zoom in
      F6      zoom out
      F8      reset
   Visible zoom buttons are also present.
4. Start Orca as the SDDM user through a systemd user service.
5. Patch only the two known bad builder values and add a fail-closed gate
   immediately before rootfs.sfs is created.
6. Produce a test ISO by replacing only rootfs.sfs in the already-bootable ISO.

Safety model
------------
- Script 01 defaults to audit-only.
- Script 02 defaults to audit-only.
- --apply is explicit.
- Every overwritten path is archived first.
- Existing themes and unrelated files are not deleted.
- The original ISO is never modified.
- The fast repack writes a separately named test ISO.

Run order
---------

cd ~/hardened-login-repair-kit

# 1. No changes:
sudo ./01_repair_login_stack.sh --audit

# 2. Apply exact stage + extracted-root repairs:
sudo ./01_repair_login_stack.sh --apply

# 3. No builder changes:
python3 ./02_patch_builder.py --audit

# 4. Apply exact builder patch:
sudo python3 ./02_patch_builder.py --apply

# 5. Re-audit both:
sudo ./01_repair_login_stack.sh --audit
python3 ./02_patch_builder.py --audit

# 6. Create a separate fast test ISO:
sudo ./03_fast_repack_test_iso.sh

Output ISO
----------
/home/corbett/hardened-arch-1.10-alpha-x86_64-login-accessibility-test.iso

Notes
-----
The Orca greeter launch is a practical SDDM workaround. The service waits for
the sddm user's D-Bus and Wayland sockets, then starts Orca in that greeter
session. The visible QML zoom controls do not depend on KWin global shortcuts.

The fast test ISO intentionally adds:
/hardened/rootfs.sfs.sha256

It does not modify the original ISO or require rebuilding the kernel, Qt, KDE,
X.Org, or the toolchain.
