#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

INSTALL_DIR = Path(__file__).resolve().parent
SNAPSHOT = INSTALL_DIR / "approved-snapshot"
TRUST = INSTALL_DIR / "trusted-files.sha512"
AUDIT = Path(
    "/home/corbett/hardened-clean-build-audit/approved-changes.jsonl"
)
TRACKED = (
    "run_clean_builder.py",
    "hardened_clean_iso_builder.py",
    "approve_clean_builder_change.py",
    "hardened-build-policy.json",
    "README.txt",
)


def sha512_file(path: Path) -> str:
    digest = hashlib.sha512()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Approve a reviewed clean-builder or policy change."
    )
    parser.add_argument("--reason", required=True)
    args = parser.parse_args()

    if os.geteuid() != 0:
        print("FAIL: Run this approval tool with sudo.", file=sys.stderr)
        return 1

    reason = args.reason.strip()
    if not reason:
        print("FAIL: A specific written reason is required.", file=sys.stderr)
        return 1

    changed: list[str] = []
    for name in TRACKED:
        current = INSTALL_DIR / name
        previous = SNAPSHOT / name
        if not current.is_file():
            print(
                f"FAIL: Missing current tracked file: {current}",
                file=sys.stderr,
            )
            return 1
        old = (
            previous.read_text(encoding="utf-8").splitlines(keepends=True)
            if previous.is_file()
            else []
        )
        new = current.read_text(encoding="utf-8").splitlines(keepends=True)
        if old != new:
            changed.append(name)
            print(f"\n===== DIFF: {name} =====")
            print(
                "".join(
                    difflib.unified_diff(
                        old,
                        new,
                        fromfile=f"approved/{name}",
                        tofile=f"current/{name}",
                    )
                )
            )

    if not changed:
        print("No tracked changes require approval.")
        return 0

    material = reason + "\n" + "\n".join(changed)
    token = hashlib.sha256(material.encode("utf-8")).hexdigest()[:12]
    print("\n===== APPROVAL REQUIRED =====")
    print(f"Reason: {reason}")
    print("Changed files:")
    for name in changed:
        print(f"  {name}")
    expected = f"APPROVE CHANGE {token}"
    answer = input(f"Type exactly '{expected}' to approve: ").strip()
    if answer != expected:
        print("FAIL: Change not approved.", file=sys.stderr)
        return 1

    SNAPSHOT.mkdir(parents=True, exist_ok=True)
    for name in TRACKED:
        shutil.copy2(INSTALL_DIR / name, SNAPSHOT / name)

    TRUST.write_text(
        "\n".join(
            f"{sha512_file(INSTALL_DIR / name)}  {name}"
            for name in TRACKED
        )
        + "\n",
        encoding="utf-8",
    )

    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "approved_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "reason": reason,
        "changed_files": changed,
        "token": token,
        "approved_by_uid": os.getuid(),
    }
    with AUDIT.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")

    for path in [TRUST, *[INSTALL_DIR / name for name in TRACKED]]:
        os.chown(path, 0, 0)
        if path.suffix == ".py":
            os.chmod(path, 0o555)
        else:
            os.chmod(path, 0o444)
    for path in SNAPSHOT.iterdir():
        if path.is_file():
            os.chown(path, 0, 0)
            os.chmod(path, 0o444)

    print("APPROVED: trusted manifest and approved snapshot updated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
