HARDENED ARCH CLEAN ISO BUILDER

PURPOSE
-------
This kit replaces the contaminated patch-on-patch builder with a separate,
root-owned builder that never executes the old builder and never reuses an old
live-root, initramfs tree, SquashFS, ESP staging tree, ISO staging tree, or ISO.

LOCKED BUILD POLICY
-------------------
Runtime root:
  /home/corbett/xorg-source-stage/rootfs
Kernel:
  /home/corbett/linux-7.1.2-build/arch/x86/boot/bzImage
Initramfs source:
  /home/corbett/linux-7.1.2-stage/initramfs
Limine:
  /home/corbett/bootloader-build/limine/BOOTX64.EFI
Limine background:
  /home/corbett/boot-theme-build/refind/hardened-arch/limine-bg.png
Output:
  /home/corbett/hardened-arch-1.10-alpha-x86_64.iso
Update repository:
  https://sourceforge.net/projects/hardened-software-update/files/

DISPLAY-MANAGER POLICY
----------------------
- GDM is installed, enabled, and selected as display-manager.service.
- GDM Wayland is explicitly enabled.
- SDDM and its source-built helpers must all be present.
- Every SDDM enablement symlink is removed from the fresh build root.
- SDDM remains installed but disabled.

STALE-ARTIFACT PROTECTION
-------------------------
- Every build receives a cryptographically random, brand-new run directory.
- The host filesystem and all input trees are read-only inside bubblewrap.
- Only that run directory is writable inside the sandbox.
- Network access is disabled by a private network namespace.
- Pacman-family binaries are hidden by default.
- The old builder is quarantined during installation and is never called.
- Full SHA-512 manifests are made for the runtime root and initramfs source
  before the build, then regenerated after the build. Any change aborts
  publication.
- early-init.log is forbidden both as a filename and as content in the live
  root, initramfs source, packed initramfs, and verified SquashFS extraction.
- The final SquashFS is fully extracted and checked.
- The final ISO's rootfs.sfs and embedded ESP are extracted and hash-compared.
- Existing output files and sidecars are rejected before the expensive build
  starts. There is no --force option.
- Publication occurs only after every check passes.

CHANGE/REVERSION PROTECTION
---------------------------
The launcher verifies SHA-512 hashes for the launcher, inner builder, policy,
and README before every build. Any unapproved edit or accidental reversion
stops the build.

To approve an intentional change:

  sudo /home/corbett/hardened-clean-builder/approve_clean_builder_change.py \
    --reason 'Exact reason for this reviewed change'

The approval tool prints the diff and requires an exact typed approval token.
It then records the reason and updates the root-owned approved snapshot.

PACKAGE-MANAGER PERMISSIONS
---------------------------
The current build does not invoke pacman. If required tools are missing, it
writes permission-request.json with the exact reason and proposed packages,
then stops.

The launcher can expose pacman-family tools for one network-isolated run only:

  sudo /home/corbett/hardened-clean-builder/run_clean_builder.py build \
    --allow-pacman \
    --permission-reason 'Exact reason'

It prints the requested capability, reason, scope, and approval token. Network
remains disabled. No package installation is automatic.

INSTALL
-------
  tar -xzf hardened-clean-builder-kit.tar.gz
  cd hardened-clean-builder-kit
  sudo ./install_clean_builder.sh

AUDIT WITHOUT BUILDING
----------------------
  sudo /home/corbett/hardened-clean-builder/run_clean_builder.py \
    build --audit-only

BUILD
-----
The output ISO and its sidecars must not already exist.

  sudo /home/corbett/hardened-clean-builder/run_clean_builder.py build

OUTPUTS
-------
- /home/corbett/hardened-arch-1.10-alpha-x86_64.iso
- /home/corbett/hardened-arch-1.10-alpha-x86_64.iso.sha512
- /home/corbett/sourceforge-manifest.example.json

IMPORTANT
---------
This design prevents silent or accidental reversion from passing verification.
A root administrator can always deliberately replace local files, but the
builder will refuse to run unless the resulting changes are explicitly
reviewed and approved into the trusted manifest.
