#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
INSTALL_DIR=/home/corbett/hardened-clean-builder
ARCHIVE_ROOT=/home/corbett/hardened-builder-archives
AUDIT_ROOT=/home/corbett/hardened-clean-build-audit
OLD_BUILDER=/home/corbett/build_hardened_arch_iso.py
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
QUARANTINE="$ARCHIVE_ROOT/contaminated-builder-$STAMP"

if [[ $EUID -ne 0 ]]; then
    echo "FAIL: Run with sudo: sudo $0" >&2
    exit 1
fi

cd "$SOURCE_DIR"
sha512sum -c trusted-files.sha512

for tool in python3 sha512sum; do
    command -v "$tool" >/dev/null || {
        echo "FAIL: Required install tool missing: $tool" >&2
        exit 1
    }
done

mkdir -p "$ARCHIVE_ROOT" "$AUDIT_ROOT"

if [[ -e "$OLD_BUILDER" ]]; then
    mkdir -p "$QUARANTINE"
    mv "$OLD_BUILDER" \
        "$QUARANTINE/build_hardened_arch_iso.py.QUARANTINED"
    sha512sum \
        "$QUARANTINE/build_hardened_arch_iso.py.QUARANTINED" \
        > "$QUARANTINE/SHA512SUMS"
    printf '%s\n' \
        'Quarantined because the old builder regenerated forbidden early-init.log state.' \
        > "$QUARANTINE/REASON.txt"
    chmod -R a-w "$QUARANTINE"
    echo "Old builder quarantined: $QUARANTINE"
fi

if [[ -e "$INSTALL_DIR" ]]; then
    echo "FAIL: Clean builder already exists: $INSTALL_DIR" >&2
    echo "Refusing to replace an approved builder silently." >&2
    echo "Use approve_clean_builder_change.py for reviewed changes." >&2
    exit 1
fi
install -d -m 0755 -o root -g root "$INSTALL_DIR"
install -m 0555 -o root -g root \
    run_clean_builder.py \
    hardened_clean_iso_builder.py \
    approve_clean_builder_change.py \
    "$INSTALL_DIR/"
install -m 0444 -o root -g root \
    hardened-build-policy.json \
    README.txt \
    trusted-files.sha512 \
    "$INSTALL_DIR/"

install -d -m 0755 -o root -g root \
    "$INSTALL_DIR/approved-snapshot"
for file in \
    run_clean_builder.py \
    hardened_clean_iso_builder.py \
    approve_clean_builder_change.py \
    hardened-build-policy.json \
    README.txt
do
    cp -a "$INSTALL_DIR/$file" \
        "$INSTALL_DIR/approved-snapshot/$file"
done
chown -R root:root "$INSTALL_DIR/approved-snapshot"
find "$INSTALL_DIR/approved-snapshot" -type f -exec chmod 0444 {} +

python3 - "$INSTALL_DIR" <<'PYCODE'
from pathlib import Path
import sys
root = Path(sys.argv[1])
for name in (
    "run_clean_builder.py",
    "hardened_clean_iso_builder.py",
    "approve_clean_builder_change.py",
):
    path = root / name
    compile(path.read_text(encoding="utf-8"), str(path), "exec")
print("Installed Python syntax: PASS")
PYCODE

echo
echo "CLEAN BUILDER INSTALLED: $INSTALL_DIR"
echo "Network is always disabled inside builds."
echo "Pacman-family tools are hidden unless explicitly approved with a reason."
echo "Old work directories are never reused."
echo
echo "Run the read-only audit first:"
echo "  sudo $INSTALL_DIR/run_clean_builder.py build --audit-only"
echo
echo "Then build:"
echo "  sudo $INSTALL_DIR/run_clean_builder.py build"
