#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys

INSTALL_DIR = Path(__file__).resolve().parent
POLICY = INSTALL_DIR / "hardened-build-policy.json"
TRUST = INSTALL_DIR / "trusted-files.sha512"
INNER = INSTALL_DIR / "hardened_clean_iso_builder.py"
PACMAN_TOOLS = (
    "/usr/bin/pacman",
    "/usr/bin/pacman-conf",
    "/usr/bin/pacman-key",
    "/usr/bin/makepkg",
    "/usr/bin/repo-add",
    "/usr/bin/repo-remove",
    "/usr/bin/paccache",
    "/usr/bin/pacstrap",
)


class LaunchError(RuntimeError):
    pass


def sha512_file(path: Path) -> str:
    digest = hashlib.sha512()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_trusted_files() -> None:
    if not TRUST.is_file():
        raise LaunchError(f"Trusted-file manifest is missing: {TRUST}")

    failures: list[str] = []
    for raw in TRUST.read_text(encoding="utf-8").splitlines():
        raw = raw.strip()
        if not raw or raw.startswith("#"):
            continue
        expected, rel = raw.split(maxsplit=1)
        rel = rel.lstrip("* ")
        path = INSTALL_DIR / rel
        if not path.is_file():
            failures.append(f"MISSING: {path}")
            continue
        actual = sha512_file(path)
        if actual != expected:
            failures.append(
                f"CHANGED: {path}\n"
                f"  approved={expected}\n"
                f"  current ={actual}"
            )

    if failures:
        raise LaunchError(
            "Builder trust verification failed. Silent or accidental changes "
            "cannot be used.\n"
            + "\n".join(failures)
            + "\nUse approve_clean_builder_change.py with a written reason "
            "after reviewing the diff."
        )


def load_policy() -> dict:
    return json.loads(POLICY.read_text(encoding="utf-8"))


def ensure_publish_targets_absent(policy: dict) -> None:
    output = Path(policy["paths"]["output_iso"])
    targets = (
        output,
        output.with_name(f"{output.name}.sha512"),
        output.parent / "sourceforge-manifest.example.json",
    )
    existing = [str(path) for path in targets if path.exists()]
    if existing:
        raise LaunchError(
            "Clean-build publication targets already exist. There is no "
            "--force or reuse path. Archive or remove them explicitly before "
            "building:\n  " + "\n  ".join(existing)
        )

def require_root() -> None:
    if os.geteuid() != 0:
        raise LaunchError(
            "The sandbox launcher must run as root so ownership, xattrs, the "
            "live account, and the ISO can be reproduced exactly.\n"
            f"Run: sudo {Path(__file__).resolve()} build"
        )


def permission_confirmation(reason: str) -> dict:
    reason = reason.strip()
    if not reason:
        raise LaunchError(
            "--allow-pacman requires --permission-reason with a specific reason."
        )

    token = hashlib.sha256(reason.encode("utf-8")).hexdigest()[:12]
    print("\n===== EXPLICIT PERMISSION REQUEST =====")
    print("Capability: expose pacman-family binaries inside this build sandbox")
    print("Scope: current run only")
    print("Network: remains disabled")
    print(f"Reason: {reason}")
    print(f"Approval token: {token}")
    expected = f"APPROVE PACMAN {token}"
    answer = input(f"Type exactly '{expected}' to approve: ").strip()
    if answer != expected:
        raise LaunchError("Pacman permission was not approved.")

    return {
        "capability": "pacman",
        "reason": reason,
        "scope": "current run only",
        "network": "disabled",
        "approved_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "token": token,
    }


def run_bwrap(
    run_dir: Path,
    audit_only: bool,
    allow_pacman: bool,
    permission_record: dict | None,
) -> int:
    bwrap = shutil.which("bwrap")
    if not bwrap:
        raise LaunchError(
            "bubblewrap (bwrap) is required. The builder will not fall back "
            "to an unsandboxed run. No package manager was invoked."
        )

    args = [
        bwrap,
        "--die-with-parent",
        "--new-session",
        "--unshare-net",
        "--unshare-pid",
        "--unshare-uts",
        "--unshare-ipc",
        "--ro-bind", "/", "/",
        "--dev", "/dev",
        "--proc", "/proc",
        "--tmpfs", "/tmp",
        "--tmpfs", "/run",
        "--bind", str(run_dir), str(run_dir),
        "--ro-bind", str(INSTALL_DIR), str(INSTALL_DIR),
        "--clearenv",
        "--setenv", "PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "--setenv", "HOME", "/root",
        "--setenv", "LANG", "C.UTF-8",
        "--setenv", "LC_ALL", "C.UTF-8",
        "--setenv", "HARDENED_BUILD_SANDBOX", "bubblewrap-no-network",
    ]

    if not allow_pacman:
        for tool in PACMAN_TOOLS:
            if Path(tool).exists():
                args.extend(["--ro-bind", "/dev/null", tool])

    if permission_record:
        (run_dir / "permission-approval.json").write_text(
            json.dumps(permission_record, indent=2) + "\n",
            encoding="utf-8",
        )

    inner_args = [
        sys.executable,
        str(INNER),
        "--inside-sandbox",
        "--policy", str(POLICY),
        "--run-dir", str(run_dir),
    ]
    if audit_only:
        inner_args.append("--audit-only")
    args.extend(inner_args)

    print("\n===== SANDBOX POLICY =====")
    print("Network: disabled by a private network namespace")
    print("Host filesystem: read-only")
    print(f"Writable build scope: {run_dir}")
    print(
        "Pacman-family tools: "
        + ("explicitly approved for this run" if allow_pacman else "hidden")
    )
    print("Old builder/work directories: never invoked or mounted writable")
    print("========================================\n")

    return subprocess.run(args, check=False).returncode


def publish(policy: dict, run_dir: Path) -> None:
    plan_path = run_dir / "publish-plan.json"
    if not plan_path.is_file():
        raise LaunchError(
            "Inner builder returned success without a publish plan. Nothing was published."
        )

    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    entries = plan.get("files", [])
    if not entries:
        raise LaunchError("Publish plan contains no files.")

    for entry in entries:
        src = run_dir / entry["source"]
        dst = Path(entry["destination"])
        expected = entry["sha512"]
        if not src.is_file():
            raise LaunchError(f"Publish source is missing: {src}")
        if dst.exists():
            raise LaunchError(
                f"Output already exists: {dst}\n"
                "This builder has no --force path. Archive or remove the "
                "existing output explicitly, then run again."
            )
        actual = sha512_file(src)
        if actual != expected:
            raise LaunchError(
                f"Publish hash mismatch for {src}: expected {expected}, got {actual}"
            )

    published: list[Path] = []
    try:
        for entry in entries:
            src = run_dir / entry["source"]
            dst = Path(entry["destination"])
            dst.parent.mkdir(parents=True, exist_ok=True)
            temp_dst = dst.with_name(f".{dst.name}.publishing-{secrets.token_hex(6)}")
            with src.open("rb") as inp, temp_dst.open("xb") as out:
                shutil.copyfileobj(inp, out, 1024 * 1024)
                out.flush()
                os.fsync(out.fileno())
            os.chmod(temp_dst, 0o644)
            os.replace(temp_dst, dst)
            published.append(dst)
    except Exception:
        for path in published:
            try:
                path.unlink()
            except OSError:
                pass
        raise

    audit_root = Path(policy["paths"]["audit_root"])
    audit_root.mkdir(parents=True, exist_ok=True)
    report = run_dir / "build-audit.json"
    if report.is_file():
        shutil.copy2(report, audit_root / f"{run_dir.name}-build-audit.json")

    print("\n===== PUBLISHED CLEAN BUILD =====")
    for path in published:
        print(path)
    print("=================================")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Launch the clean Hardened Arch ISO builder in a no-network sandbox."
    )
    sub = parser.add_subparsers(dest="command", required=True)
    build = sub.add_parser("build")
    build.add_argument("--audit-only", action="store_true")
    build.add_argument("--allow-pacman", action="store_true")
    build.add_argument("--permission-reason", default="")
    args = parser.parse_args()

    require_root()
    verify_trusted_files()
    policy = load_policy()
    if not args.audit_only:
        ensure_publish_targets_absent(policy)

    run_root = Path(policy["paths"]["run_root"])
    run_root.mkdir(parents=True, exist_ok=True)
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = run_root / f"run-{timestamp}-{secrets.token_hex(5)}"
    run_dir.mkdir(mode=0o700)

    permission_record = None
    if args.allow_pacman:
        permission_record = permission_confirmation(args.permission_reason)

    rc = run_bwrap(
        run_dir=run_dir,
        audit_only=args.audit_only,
        allow_pacman=args.allow_pacman,
        permission_record=permission_record,
    )
    if rc != 0:
        print(f"\nBUILD STOPPED: sandboxed builder exit status {rc}")
        print(f"Run retained for evidence: {run_dir}")
        return rc

    if args.audit_only:
        print(f"\nAUDIT PASSED. No ISO was built. Report: {run_dir / 'build-audit.json'}")
        return 0

    publish(policy, run_dir)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except LaunchError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
