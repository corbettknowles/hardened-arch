#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys


class BuildError(RuntimeError):
    pass


def shell_quote(value: str) -> str:
    import shlex
    return shlex.quote(value)


class Builder:
    def __init__(self, policy: dict, run_dir: Path, audit_only: bool) -> None:
        self.policy = policy
        self.run_dir = run_dir
        self.audit_only = audit_only
        self.paths = policy["paths"]
        self.jobs = int(policy.get("jobs", 4))
        self.log_path = run_dir / "commands.log"
        self.audit: dict = {
            "schema": 1,
            "project": policy["project"],
            "version": policy["version"],
            "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "sandbox": os.environ.get("HARDENED_BUILD_SANDBOX"),
            "network": "disabled",
            "pacman_invoked": False,
            "run_dir": str(run_dir),
            "checks": [],
            "changes": [],
            "input_manifests": {},
            "artifacts": {},
        }

        self.live_root = run_dir / "work/live-root"
        self.initramfs_tree = run_dir / "work/initramfs-tree"
        self.initramfs_verify = run_dir / "work/initramfs-verify"
        self.iso_root = run_dir / "work/iso-root"
        self.esp_staging = run_dir / "work/esp-staging"
        self.squashfs_verify = run_dir / "work/squashfs-verify"
        self.publish_dir = run_dir / "publish"

    def log(self, message: str) -> None:
        print(message, flush=True)

    def record_check(self, name: str, passed: bool, detail: str = "") -> None:
        self.audit["checks"].append(
            {"name": name, "passed": passed, "detail": detail}
        )
        if not passed:
            raise BuildError(f"{name}: {detail}")

    def run(
        self,
        args: list[str | os.PathLike[str]],
        *,
        cwd: Path | None = None,
        check: bool = True,
        input_text: str | None = None,
    ) -> subprocess.CompletedProcess[str]:
        command = [os.fspath(item) for item in args]
        rendered = " ".join(repr(item) for item in command)
        with self.log_path.open("a", encoding="utf-8") as log:
            log.write(f"$ {rendered}\n")
        completed = subprocess.run(
            command,
            cwd=cwd,
            text=True,
            input=input_text,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        with self.log_path.open("a", encoding="utf-8") as log:
            log.write(completed.stdout)
            if completed.stdout and not completed.stdout.endswith("\n"):
                log.write("\n")
            log.write(f"[exit={completed.returncode}]\n")
        if completed.stdout:
            print(completed.stdout, end="")
        if check and completed.returncode != 0:
            raise BuildError(
                f"Command failed with status {completed.returncode}: {rendered}"
            )
        return completed

    @staticmethod
    def sha512_file(path: Path) -> str:
        digest = hashlib.sha512()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def require_sandbox(self) -> None:
        value = os.environ.get("HARDENED_BUILD_SANDBOX")
        self.record_check(
            "sandbox active",
            value == "bubblewrap-no-network",
            f"expected bubblewrap-no-network, got {value!r}",
        )

    def require_empty_unique_run(self) -> None:
        resolved = self.run_dir.resolve()
        run_root = Path(self.paths["run_root"]).resolve()
        self.record_check(
            "run directory scope",
            run_root in resolved.parents,
            f"{resolved} is not beneath {run_root}",
        )
        allowed = {"permission-approval.json"}
        unexpected = [
            path.name for path in self.run_dir.iterdir()
            if path.name not in allowed
        ]
        self.record_check(
            "new run directory",
            not unexpected,
            f"unexpected pre-existing entries: {unexpected}",
        )

    def required_tools(self) -> None:
        tools = [
            "rsync",
            "mksquashfs",
            "unsquashfs",
            "cpio",
            "zstd",
            "xorriso",
            "mkfs.fat",
            "mcopy",
            "mmd",
            "mdir",
            "systemctl",
            "chroot",
            "ldd",
            "readelf",
            "sha512sum",
        ]
        missing = [tool for tool in tools if shutil.which(tool) is None]
        if missing:
            package_map = {
                "rsync": "rsync",
                "mksquashfs": "squashfs-tools",
                "unsquashfs": "squashfs-tools",
                "cpio": "cpio",
                "zstd": "zstd",
                "xorriso": "libisoburn",
                "mkfs.fat": "dosfstools",
                "mcopy": "mtools",
                "mmd": "mtools",
                "mdir": "mtools",
                "systemctl": "systemd",
                "chroot": "coreutils",
                "ldd": "glibc",
                "readelf": "binutils",
                "sha512sum": "coreutils",
            }
            request = {
                "type": "package_manager",
                "reason": "Required local ISO build tools are missing.",
                "missing_tools": missing,
                "suggested_packages": sorted({package_map[x] for x in missing}),
                "network_permission": "not granted",
                "automatic_install": False,
            }
            request_path = self.run_dir / "permission-request.json"
            request_path.write_text(
                json.dumps(request, indent=2) + "\n",
                encoding="utf-8",
            )
            raise BuildError(
                "Missing required tools: "
                + ", ".join(missing)
                + ". Exact reason and proposed packages: "
                + str(request_path)
                + ". The builder did not invoke pacman."
            )
        self.record_check("required host tools", True, ", ".join(tools))

    def validate_policy(self) -> None:
        dm = self.policy["display_manager"]
        self.record_check(
            "GDM policy",
            dm["enabled"] == "gdm.service",
            f"enabled display manager is {dm['enabled']!r}",
        )
        self.record_check(
            "SDDM disabled policy",
            "sddm.service" in dm["present_but_disabled"],
            "sddm.service must remain installed but disabled",
        )
        self.record_check(
            "update URL locked",
            self.policy["repo_url"]
            == "https://sourceforge.net/projects/hardened-software-update/files/",
            self.policy["repo_url"],
        )
        self.record_check(
            "forbidden diagnostic",
            "early-init.log" in self.policy["forbidden"]["path_basenames"],
            "early-init.log must be forbidden",
        )

    def validate_input_paths(self) -> None:
        for key in ("runtime_root", "initramfs_source"):
            path = Path(self.paths[key])
            self.record_check(f"input directory {key}", path.is_dir(), str(path))
        for key in ("kernel_bzimage", "limine_efi", "limine_background"):
            path = Path(self.paths[key])
            self.record_check(f"input file {key}", path.is_file(), str(path))

    def tree_manifest(self, root: Path, output: Path) -> str:
        digest = hashlib.sha512()
        with output.open("w", encoding="utf-8") as stream:
            paths = sorted(
                root.rglob("*"),
                key=lambda path: os.fsencode(str(path.relative_to(root))),
            )
            for path in paths:
                rel = path.relative_to(root).as_posix()
                st = path.lstat()
                item: dict = {
                    "path": rel,
                    "mode": stat.S_IMODE(st.st_mode),
                    "uid": st.st_uid,
                    "gid": st.st_gid,
                    "type": "other",
                }
                if path.is_symlink():
                    item["type"] = "symlink"
                    item["target"] = os.readlink(path)
                elif path.is_file():
                    item["type"] = "file"
                    item["size"] = st.st_size
                    item["sha512"] = self.sha512_file(path)
                elif path.is_dir():
                    item["type"] = "dir"
                else:
                    item["rdev"] = st.st_rdev
                line = json.dumps(item, sort_keys=True, separators=(",", ":"))
                stream.write(line + "\n")
                digest.update(line.encode("utf-8"))
                digest.update(b"\n")
        return digest.hexdigest()

    def create_input_manifests(self) -> None:
        manifest_dir = self.run_dir / "input-manifests"
        manifest_dir.mkdir()
        for key in ("runtime_root", "initramfs_source"):
            root = Path(self.paths[key])
            output = manifest_dir / f"{key}.jsonl"
            summary = self.tree_manifest(root, output)
            self.audit["input_manifests"][key] = {
                "root": str(root),
                "manifest": str(output),
                "sha512": summary,
            }
            self.log(f"{key} manifest SHA-512: {summary}")

        for key in ("kernel_bzimage", "limine_efi", "limine_background"):
            path = Path(self.paths[key])
            self.audit["input_manifests"][key] = {
                "path": str(path),
                "sha512": self.sha512_file(path),
                "size": path.stat().st_size,
            }

    def verify_inputs_unchanged(self) -> None:
        verify_dir = self.run_dir / "input-manifests-final"
        verify_dir.mkdir()
        for key in ("runtime_root", "initramfs_source"):
            root = Path(self.paths[key])
            output = verify_dir / f"{key}.jsonl"
            current = self.tree_manifest(root, output)
            expected = self.audit["input_manifests"][key]["sha512"]
            self.record_check(
                f"input unchanged {key}",
                current == expected,
                f"initial={expected} final={current}",
            )
        for key in ("kernel_bzimage", "limine_efi", "limine_background"):
            path = Path(self.paths[key])
            current = self.sha512_file(path)
            expected = self.audit["input_manifests"][key]["sha512"]
            self.record_check(
                f"input unchanged {key}",
                current == expected,
                f"initial={expected} final={current}",
            )

    def scan_forbidden(self, root: Path, label: str) -> None:
        forbidden_names = set(self.policy["forbidden"]["path_basenames"])
        needles = [
            value.encode("utf-8")
            for value in self.policy["forbidden"]["content_strings"]
        ]
        bad_paths: list[str] = []
        bad_content: list[str] = []
        for path in root.rglob("*"):
            if path.name in forbidden_names:
                bad_paths.append(str(path))
            if path.is_file() and not path.is_symlink():
                try:
                    size = path.stat().st_size
                except OSError:
                    continue
                if size > 32 * 1024 * 1024:
                    continue
                try:
                    data = path.read_bytes()
                except OSError:
                    continue
                if any(needle in data for needle in needles):
                    bad_content.append(str(path))
        self.record_check(
            f"forbidden artifacts absent in {label}",
            not bad_paths and not bad_content,
            f"paths={bad_paths}; content={bad_content}",
        )

    def copy_runtime_root(self) -> None:
        self.log("\n===== FRESH LIVE ROOT =====")
        self.live_root.mkdir(parents=True)
        self.run(
            [
                "rsync",
                "-aHAX",
                "--numeric-ids",
                "--delete",
                "--one-file-system",
                "--exclude=/proc/*",
                "--exclude=/sys/*",
                "--exclude=/dev/*",
                "--exclude=/run/*",
                "--exclude=/tmp/*",
                f"{self.paths['runtime_root']}/",
                f"{self.live_root}/",
            ]
        )
        for rel, mode in (
            ("proc", 0o555),
            ("sys", 0o555),
            ("dev", 0o755),
            ("run", 0o755),
            ("tmp", 0o1777),
        ):
            path = self.live_root / rel
            path.mkdir(exist_ok=True)
            os.chmod(path, mode)
        self.scan_forbidden(self.live_root, "fresh live root")

    def path_in_root(self, absolute: str) -> Path:
        if not absolute.startswith("/"):
            raise BuildError(f"Expected absolute root path: {absolute}")
        return self.live_root / absolute.lstrip("/")

    def verify_required_components(self) -> None:
        required = self.policy["required_paths"]
        missing: list[str] = []
        nonexec: list[str] = []
        for absolute in required["executables"]:
            path = self.path_in_root(absolute)
            if not path.is_file():
                missing.append(absolute)
            elif not os.access(path, os.X_OK):
                nonexec.append(absolute)
        for absolute in required["files"]:
            if not self.path_in_root(absolute).exists():
                missing.append(absolute)
        for alternatives in required["any_of"]:
            if not any(self.path_in_root(item).exists() for item in alternatives):
                missing.append("ANY OF: " + " | ".join(alternatives))
        self.record_check(
            "all required GDM/SDDM/Plasma/Wayland/accessibility components",
            not missing and not nonexec,
            f"missing={missing}; non-executable={nonexec}",
        )

        for executable in (
            "/usr/sbin/gdm",
            "/usr/bin/sddm",
            "/usr/bin/sddm-greeter-qt6",
            "/usr/lib/sddm-helper",
            "/usr/lib/sddm-helper-start-wayland",
            "/usr/lib/sddm-helper-start-x11user",
            "/usr/bin/startplasma-wayland",
            "/usr/bin/kwin_wayland",
            "/usr/bin/plasmashell",
            "/usr/bin/ksmserver",
        ):
            staged = self.path_in_root(executable)
            with staged.open("rb") as stream:
                magic = stream.read(4)
            if magic != b"\x7fELF":
                self.record_check(
                    f"executable script present {executable}",
                    os.access(staged, os.X_OK),
                    "non-ELF executable; ldd intentionally skipped",
                )
                continue
            result = self.run(
                ["chroot", str(self.live_root), "/usr/bin/ldd", executable],
                check=False,
            )
            bad = "not found" in result.stdout
            self.record_check(
                f"runtime libraries {executable}",
                result.returncode == 0 and not bad,
                result.stdout.strip(),
            )

    def ensure_live_user(self) -> None:
        user = self.policy["live_user"]
        passwd_path = self.live_root / "etc/passwd"
        passwd_text = passwd_path.read_text(encoding="utf-8")
        existing_lines = [
            line
            for line in passwd_text.splitlines()
            if line.startswith(f"{user['name']}:")
        ]

        if not existing_lines:
            uid_owner = [
                line
                for line in passwd_text.splitlines()
                if len(line.split(":")) > 2
                and line.split(":")[2] == str(user["uid"])
            ]
            self.record_check(
                "live UID available",
                not uid_owner,
                f"UID {user['uid']} already belongs to {uid_owner}",
            )

            group_text = (self.live_root / "etc/group").read_text(encoding="utf-8")
            available = {
                line.split(":", 1)[0]
                for line in group_text.splitlines()
                if ":" in line
            }
            groups = [name for name in user["groups"] if name in available]
            command = [
                "chroot",
                str(self.live_root),
                "/usr/bin/useradd",
                "-m",
                "-u",
                str(user["uid"]),
                "-s",
                user["shell"],
            ]
            if groups:
                command.extend(["-G", ",".join(groups)])
            command.append(user["name"])
            self.run(command)
            self.audit["changes"].append(
                "created hardened live user in fresh build root"
            )
        else:
            fields = existing_lines[0].split(":")
            self.record_check(
                "existing live user UID/GID/shell",
                fields[2] == str(user["uid"])
                and fields[3] == str(user["gid"])
                and fields[6] == user["shell"],
                existing_lines[0],
            )

        self.run(
            ["chroot", str(self.live_root), "/usr/bin/chpasswd"],
            input_text=f"{user['name']}:{user['password']}\n",
        )

        home = self.live_root / "home" / user["name"]
        home.mkdir(parents=True, exist_ok=True)
        os.chown(home, user["uid"], user["gid"])
        os.chmod(home, 0o700)

        dmrc = home / ".dmrc"
        dmrc.write_text(
            f"[Desktop]\nSession={user['session']}\n",
            encoding="utf-8",
        )
        os.chown(dmrc, user["uid"], user["gid"])
        os.chmod(dmrc, 0o644)

        accounts = self.live_root / "var/lib/AccountsService/users"
        accounts.mkdir(parents=True, exist_ok=True)
        account_file = accounts / user["name"]
        account_file.write_text(
            "[User]\n"
            f"Session={user['session']}\n"
            "SystemAccount=false\n",
            encoding="utf-8",
        )
        os.chmod(account_file, 0o600)

        result = self.run(
            [
                "chroot",
                str(self.live_root),
                "/usr/bin/getent",
                "passwd",
                user["name"],
            ]
        )
        self.record_check(
            "live user identity",
            f":{user['uid']}:{user['gid']}:" in result.stdout,
            result.stdout.strip(),
        )

    def configure_display_manager(self) -> None:
        self.log("\n===== GDM ACTIVE; SDDM PRESENT BUT DISABLED =====")
        gdm = self.path_in_root("/usr/lib/systemd/system/gdm.service")
        sddm = self.path_in_root("/usr/lib/systemd/system/sddm.service")
        self.record_check("GDM service present", gdm.is_file(), str(gdm))
        self.record_check("SDDM service present", sddm.is_file(), str(sddm))

        self.run(
            ["systemctl", f"--root={self.live_root}", "disable", "sddm.service"],
            check=False,
        )
        self.run(
            ["systemctl", f"--root={self.live_root}", "enable", "gdm.service"]
        )
        self.run(
            [
                "systemctl",
                f"--root={self.live_root}",
                "set-default",
                "graphical.target",
            ]
        )

        dm_link = self.live_root / "etc/systemd/system/display-manager.service"
        if dm_link.exists() or dm_link.is_symlink():
            dm_link.unlink()
        dm_link.parent.mkdir(parents=True, exist_ok=True)
        os.symlink("/usr/lib/systemd/system/gdm.service", dm_link)

        for path in (self.live_root / "etc/systemd/system").rglob("*"):
            if not path.is_symlink():
                continue
            target = os.readlink(path)
            if "sddm.service" in target and path != dm_link:
                path.unlink()
                self.audit["changes"].append(
                    f"removed SDDM enablement symlink "
                    f"{path.relative_to(self.live_root)}"
                )

        gdm_conf = self.live_root / "etc/gdm/custom.conf"
        gdm_conf.parent.mkdir(parents=True, exist_ok=True)
        gdm_conf.write_text(
            "[daemon]\n"
            "WaylandEnable=true\n"
            "AutomaticLoginEnable=false\n"
            "\n"
            "[security]\n"
            "\n"
            "[xdmcp]\n"
            "\n"
            "[chooser]\n"
            "\n"
            "[debug]\n"
            "Enable=false\n",
            encoding="utf-8",
        )
        os.chmod(gdm_conf, 0o644)

        self.record_check(
            "display-manager alias is GDM",
            dm_link.is_symlink()
            and os.readlink(dm_link) == "/usr/lib/systemd/system/gdm.service",
            os.readlink(dm_link) if dm_link.is_symlink() else "not a symlink",
        )

        sddm_links = []
        for path in (self.live_root / "etc/systemd/system").rglob("*"):
            if path.is_symlink() and "sddm.service" in os.readlink(path):
                sddm_links.append(str(path.relative_to(self.live_root)))
        self.record_check(
            "SDDM installed but disabled",
            not sddm_links and sddm.is_file(),
            f"enablement links={sddm_links}",
        )

        for account in ("gdm", "sddm"):
            account_result = self.run(
                [
                    "chroot",
                    str(self.live_root),
                    "/usr/bin/getent",
                    "passwd",
                    account,
                ],
                check=False,
            )
            self.record_check(
                f"service account {account}",
                account_result.returncode == 0 and bool(account_result.stdout.strip()),
                account_result.stdout.strip(),
            )

        result = self.run(
            [
                "systemctl",
                f"--root={self.live_root}",
                "is-enabled",
                "gdm.service",
            ],
            check=False,
        )
        self.record_check(
            "GDM enabled",
            result.returncode == 0
            and result.stdout.strip() in {"enabled", "alias", "linked"},
            result.stdout.strip(),
        )

    def configure_update_url(self) -> None:
        url = self.policy["repo_url"]
        config = self.live_root / "etc/hardened-arch/update-repository.conf"
        config.parent.mkdir(parents=True, exist_ok=True)
        config.write_text(
            "# Generated from locked Hardened Arch build policy.\n"
            f"REPOSITORY_URL={url}\n",
            encoding="utf-8",
        )
        os.chmod(config, 0o644)

        replaced = []
        for base in (
            self.live_root / "usr/local/sbin",
            self.live_root / "usr/local/libexec",
        ):
            if not base.is_dir():
                continue
            for path in base.rglob("*"):
                if not path.is_file() or path.stat().st_size > 4 * 1024 * 1024:
                    continue
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    continue
                if "__UPDATE_REPO_URL__" in text:
                    path.write_text(
                        text.replace("__UPDATE_REPO_URL__", url),
                        encoding="utf-8",
                    )
                    replaced.append(str(path.relative_to(self.live_root)))
        self.audit["changes"].append(
            {"update_url": url, "placeholder_replacements": replaced}
        )
        self.record_check(
            "update URL written from locked policy",
            url in config.read_text(encoding="utf-8"),
            str(config),
        )

    def prepare_initramfs(self) -> Path:
        self.log("\n===== FRESH INITRAMFS =====")
        self.initramfs_tree.mkdir(parents=True)
        self.run(
            [
                "rsync",
                "-aHAX",
                "--numeric-ids",
                "--delete",
                "--one-file-system",
                f"{self.paths['initramfs_source']}/",
                f"{self.initramfs_tree}/",
            ]
        )
        self.scan_forbidden(self.initramfs_tree, "fresh initramfs tree")
        init = self.initramfs_tree / "init"
        self.record_check(
            "initramfs /init present",
            init.exists() or init.is_symlink(),
            str(init),
        )
        if init.exists() and not init.is_symlink():
            self.record_check(
                "initramfs /init executable",
                os.access(init, os.X_OK),
                oct(stat.S_IMODE(init.stat().st_mode)),
            )

        output = self.run_dir / (
            f"initramfs-live-{self.policy['kernel_release']}.img.zst"
        )
        script = (
            "set -o pipefail; "
            "find . -print0 | sort -z | "
            "cpio --null --create --format=newc --owner=0:0 "
            "--reproducible 2>/dev/null | "
            f"zstd -19 -T{self.jobs} -q -o {shell_quote(str(output))}"
        )
        self.run(["bash", "-c", script], cwd=self.initramfs_tree)

        self.initramfs_verify.mkdir(parents=True)
        extract = (
            "set -o pipefail; "
            f"zstd -dc {shell_quote(str(output))} | cpio -idmu --quiet"
        )
        self.run(["bash", "-c", extract], cwd=self.initramfs_verify)
        self.scan_forbidden(self.initramfs_verify, "packed initramfs")
        packed_init = self.initramfs_verify / "init"
        self.record_check(
            "packed initramfs /init present",
            packed_init.exists() or packed_init.is_symlink(),
            str(packed_init),
        )
        self.audit["artifacts"]["initramfs"] = {
            "path": str(output),
            "sha512": self.sha512_file(output),
            "size": output.stat().st_size,
        }
        return output

    def build_squashfs(self) -> Path:
        self.log("\n===== FRESH SQUASHFS =====")
        output = self.run_dir / self.policy["build"]["rootfs_filename"]
        self.run(
            [
                "mksquashfs",
                str(self.live_root),
                str(output),
                "-comp",
                self.policy["build"]["squashfs_compression"],
                "-b",
                self.policy["build"]["squashfs_block_size"],
                "-noappend",
                "-no-progress",
            ]
        )
        self.run(["unsquashfs", "-s", str(output)])
        if self.policy["build"].get("full_squashfs_extract_verify", False):
            self.run(
                [
                    "unsquashfs",
                    "-d",
                    str(self.squashfs_verify),
                    str(output),
                ]
            )
            self.scan_forbidden(
                self.squashfs_verify,
                "verified SquashFS extraction",
            )
            dm = (
                self.squashfs_verify
                / "etc/systemd/system/display-manager.service"
            )
            self.record_check(
                "SquashFS display manager is GDM",
                dm.is_symlink()
                and os.readlink(dm) == "/usr/lib/systemd/system/gdm.service",
                os.readlink(dm) if dm.is_symlink() else "not a symlink",
            )
        self.audit["artifacts"]["rootfs"] = {
            "path": str(output),
            "sha512": self.sha512_file(output),
            "size": output.stat().st_size,
        }
        return output

    def write_marker(self) -> Path:
        marker = self.iso_root / self.policy["build"]["media_marker"]
        marker.write_text(
            "Hardened Arch live media\n"
            f"Kernel={self.policy['kernel_release']}\n"
            f"RootPayload=/{self.policy['build']['rootfs_filename']}\n"
            "WritableLayer=tmpfs-overlay\n"
            f"BuildVersion={self.policy['version']}\n",
            encoding="utf-8",
        )
        return marker

    def limine_config(self) -> str:
        kver = self.policy["kernel_release"]
        label = self.policy["volume_label"]
        return (
            "timeout: 5\n"
            "default_entry: 1\n"
            "interface_branding: Hardened Arch Linux\n"
            "editor_enabled: no\n"
            "wallpaper: boot():/EFI/BOOT/limine-bg.png\n"
            "wallpaper_style: stretched\n"
            "\n"
            "/Hardened Arch Live (GDM + Plasma Wayland)\n"
            "    protocol: linux\n"
            f"    path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n"
            f"    module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n"
            f"    cmdline: iso_label={label} hardened.mode=live rw quiet splash "
            "systemd.unit=graphical.target\n"
            "\n"
            "/Hardened Arch Live (Verbose Diagnostic)\n"
            "    protocol: linux\n"
            f"    path: boot():/EFI/Linux/vmlinuz-{kver}.efi\n"
            f"    module_path: boot():/EFI/Linux/initramfs-live-{kver}.img.zst\n"
            f"    cmdline: iso_label={label} hardened.mode=live rw "
            "loglevel=7 systemd.log_level=debug systemd.show_status=yes "
            "systemd.unit=graphical.target\n"
        )

    def build_esp(self, initramfs: Path) -> Path:
        self.log("\n===== FRESH LIMINE ESP =====")
        self.esp_staging.mkdir(parents=True)
        efi_boot = self.esp_staging / "EFI/BOOT"
        efi_linux = self.esp_staging / "EFI/Linux"
        efi_boot.mkdir(parents=True)
        efi_linux.mkdir(parents=True)

        shutil.copy2(self.paths["limine_efi"], efi_boot / "BOOTX64.EFI")
        shutil.copy2(
            self.paths["limine_background"],
            efi_boot / "limine-bg.png",
        )
        (efi_boot / "limine.conf").write_text(
            self.limine_config(),
            encoding="utf-8",
        )
        kernel_name = f"vmlinuz-{self.policy['kernel_release']}.efi"
        initramfs_name = (
            f"initramfs-live-{self.policy['kernel_release']}.img.zst"
        )
        shutil.copy2(
            self.paths["kernel_bzimage"],
            efi_linux / kernel_name,
        )
        shutil.copy2(initramfs, efi_linux / initramfs_name)

        total = sum(
            path.stat().st_size
            for path in self.esp_staging.rglob("*")
            if path.is_file()
        )
        size_mib = max(
            64,
            ((total + 32 * 1024 * 1024) // (1024 * 1024)) + 1,
        )
        image = self.run_dir / "efiboot.img"
        with image.open("wb") as stream:
            stream.truncate(size_mib * 1024 * 1024)

        self.run(
            ["mkfs.fat", "-F", "32", "-n", "HARDENED_EFI", str(image)]
        )
        for directory in ("::/EFI", "::/EFI/BOOT", "::/EFI/Linux"):
            self.run(["mmd", "-i", str(image), directory])

        copies = (
            (efi_boot / "BOOTX64.EFI", "::/EFI/BOOT/BOOTX64.EFI"),
            (efi_boot / "limine-bg.png", "::/EFI/BOOT/limine-bg.png"),
            (efi_boot / "limine.conf", "::/EFI/BOOT/limine.conf"),
            (efi_linux / kernel_name, f"::/EFI/Linux/{kernel_name}"),
            (efi_linux / initramfs_name, f"::/EFI/Linux/{initramfs_name}"),
        )
        for src, dst in copies:
            self.run(["mcopy", "-i", str(image), "-o", str(src), dst])

        listing = self.run(["mdir", "-i", str(image), "-/", "::/EFI"])
        for required in (
            "BOOTX64.EFI",
            "limine.conf",
            kernel_name,
            initramfs_name,
        ):
            self.record_check(
                f"ESP contains {required}",
                required in listing.stdout,
                listing.stdout,
            )

        self.audit["artifacts"]["esp"] = {
            "path": str(image),
            "sha512": self.sha512_file(image),
            "size": image.stat().st_size,
        }
        return image

    def build_iso(self, rootfs: Path, esp: Path) -> Path:
        self.log("\n===== FRESH ISO =====")
        self.iso_root.mkdir(parents=True)
        shutil.copy2(rootfs, self.iso_root / rootfs.name)
        self.write_marker()
        embedded = self.iso_root / "EFI/BOOT/efiboot.img"
        embedded.parent.mkdir(parents=True)
        shutil.copy2(esp, embedded)

        self.publish_dir.mkdir(parents=True)
        temp_iso = self.publish_dir / Path(self.paths["output_iso"]).name
        self.run(
            [
                "xorriso",
                "-as",
                "mkisofs",
                "-iso-level",
                "3",
                "-full-iso9660-filenames",
                "-R",
                "-J",
                "-joliet-long",
                "-V",
                self.policy["volume_label"],
                "-o",
                str(temp_iso),
                "-append_partition",
                "2",
                "0xef",
                str(esp),
                "-appended_part_as_gpt",
                "-eltorito-alt-boot",
                "-e",
                "--interval:appended_partition_2:all::",
                "-no-emul-boot",
                str(self.iso_root),
            ]
        )

        report = self.run(
            [
                "xorriso",
                "-indev",
                str(temp_iso),
                "-report_el_torito",
                "plain",
            ]
        )
        upper = report.stdout.upper()
        self.record_check(
            "ISO has UEFI El Torito boot image",
            "EFI" in upper or "UEFI" in upper,
            report.stdout,
        )

        verify_dir = self.run_dir / "work/iso-extract"
        verify_dir.mkdir(parents=True)
        extracted_rootfs = verify_dir / rootfs.name
        extracted_esp = verify_dir / "efiboot.img"
        self.run(
            [
                "xorriso",
                "-osirrox",
                "on",
                "-indev",
                str(temp_iso),
                "-extract",
                f"/{rootfs.name}",
                str(extracted_rootfs),
                "-extract",
                "/EFI/BOOT/efiboot.img",
                str(extracted_esp),
            ]
        )
        self.record_check(
            "ISO rootfs hash",
            self.sha512_file(extracted_rootfs) == self.sha512_file(rootfs),
            str(extracted_rootfs),
        )
        self.record_check(
            "ISO embedded ESP hash",
            self.sha512_file(extracted_esp) == self.sha512_file(esp),
            str(extracted_esp),
        )

        iso_hash = self.sha512_file(temp_iso)
        sidecar = self.publish_dir / f"{temp_iso.name}.sha512"
        sidecar.write_text(
            f"{iso_hash}  {temp_iso.name}\n",
            encoding="utf-8",
        )

        manifest = self.publish_dir / "sourceforge-manifest.example.json"
        manifest.write_text(
            json.dumps(
                {
                    "schema": 1,
                    "channel": "alpha",
                    "version": self.policy["version"],
                    "architecture": self.policy["architecture"],
                    "published": None,
                    "repository_url": self.policy["repo_url"],
                    "iso": {
                        "filename": temp_iso.name,
                        "sha512": iso_hash,
                        "size": temp_iso.stat().st_size,
                    },
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        self.audit["artifacts"]["iso"] = {
            "path": str(temp_iso),
            "sha512": iso_hash,
            "size": temp_iso.stat().st_size,
        }
        return temp_iso

    def write_publish_plan(self, iso: Path) -> None:
        output = Path(self.paths["output_iso"])
        files = [
            (iso, output),
            (
                self.publish_dir / f"{iso.name}.sha512",
                output.with_name(f"{output.name}.sha512"),
            ),
            (
                self.publish_dir / "sourceforge-manifest.example.json",
                output.parent / "sourceforge-manifest.example.json",
            ),
        ]
        plan = {
            "schema": 1,
            "files": [
                {
                    "source": str(src.relative_to(self.run_dir)),
                    "destination": str(dst),
                    "sha512": self.sha512_file(src),
                    "size": src.stat().st_size,
                }
                for src, dst in files
            ],
        }
        (self.run_dir / "publish-plan.json").write_text(
            json.dumps(plan, indent=2) + "\n",
            encoding="utf-8",
        )

    def cleanup_successful_work(self) -> None:
        if self.policy["build"].get("retain_successful_work", False):
            return
        work = self.run_dir / "work"
        if work.exists():
            shutil.rmtree(work)
        for path in (
            self.run_dir / self.policy["build"]["rootfs_filename"],
            self.run_dir / "efiboot.img",
            self.run_dir
            / f"initramfs-live-{self.policy['kernel_release']}.img.zst",
        ):
            if path.exists():
                path.unlink()

    def finish_audit(self, success: bool, error: str | None = None) -> None:
        self.audit["success"] = success
        self.audit["finished_utc"] = dt.datetime.now(
            dt.timezone.utc
        ).isoformat()
        if error:
            self.audit["error"] = error
        (self.run_dir / "build-audit.json").write_text(
            json.dumps(self.audit, indent=2) + "\n",
            encoding="utf-8",
        )

    def build(self) -> None:
        self.require_sandbox()
        self.require_empty_unique_run()
        self.required_tools()
        self.validate_policy()
        self.validate_input_paths()
        self.create_input_manifests()
        self.copy_runtime_root()
        self.verify_required_components()
        self.ensure_live_user()
        self.configure_display_manager()
        self.configure_update_url()
        self.scan_forbidden(self.live_root, "configured live root")

        if self.audit_only:
            self.verify_inputs_unchanged()
            self.finish_audit(True)
            return

        initramfs = self.prepare_initramfs()
        rootfs = self.build_squashfs()
        esp = self.build_esp(initramfs)
        iso = self.build_iso(rootfs, esp)
        self.verify_inputs_unchanged()
        self.write_publish_plan(iso)
        self.cleanup_successful_work()
        self.finish_audit(True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inside-sandbox", action="store_true")
    parser.add_argument("--policy", required=True)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()

    if not args.inside_sandbox:
        raise BuildError(
            "Direct invocation is forbidden; use run_clean_builder.py."
        )

    policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
    builder = Builder(policy, Path(args.run_dir), args.audit_only)
    try:
        builder.build()
    except Exception as exc:
        builder.finish_audit(False, str(exc))
        raise
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BuildError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
